@echo off
rem Full suite (about 65 minutes on an RTX 3060 Ti) followed by the 30-minute sustained run (D-39).
rem Mains power, nothing else running. Results land in the results folder next to this file.
rem Set MARBLERT_NO_PAUSE=1 to skip the closing pause (scripted runs).
setlocal
set "DIR=%~dp0"
set "WL=%DIR%assets\workloads"
"%DIR%bin\marblert.exe" --shader-dir "%DIR%shaders" --bench "%WL%\w0_gbuffer.json" "%WL%\w1_primary.json" "%WL%\w2_shadow_one.json" "%WL%\w3_many_light.json" "%WL%\w4_mirror_reflections.json" "%WL%\w5_rough_reflections.json" "%WL%\w6_glass_bounces.json" "%WL%\w7_alpha_tested.json" "%WL%\w8_moving_instances.json" "%WL%\w8refit_moving_instances.json" "%WL%\w9_dense_static.json" "%WL%\w10_one_bounce.json" "%WL%\c1_composite.json" --out "%DIR%results" --suite full
if errorlevel 1 goto failed
"%DIR%bin\marblert.exe" --shader-dir "%DIR%shaders" --bench "%WL%\c1_composite.json" --sustained 30 --out "%DIR%results" --suite full
if errorlevel 1 goto failed
echo.
echo Done. Zip and send back the folder: %DIR%results
if not defined MARBLERT_NO_PAUSE pause
exit /b 0
:failed
echo.
echo The run stopped with an error. Send back the text in this window and the results folder.
if not defined MARBLERT_NO_PAUSE pause
exit /b 1
