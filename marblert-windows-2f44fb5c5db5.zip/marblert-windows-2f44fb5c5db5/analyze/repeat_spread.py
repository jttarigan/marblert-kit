#!/usr/bin/env python3
"""Slow repeats and the reported value (D-35), per run of one or more suite bundles.

Usage: repeat_spread.py <bundle> [<bundle> ...] [--json]

The rule (the same as engine/bench/repeat_rule.h): a timed repeat whose GPU frame median is more than 5 % above the
fastest timed repeat is flagged; the reported value is the median of the clean (unflagged) repeats; a run with fewer
than 3 clean repeats is re-measured once at the end of the suite, and the re-measure is what gets reported; V4 passes
when the CoV of the clean repeats is below 2 % for frames under 1 ms and below 0.5 % otherwise, and a run that still
has too few clean repeats fails it; V7 compares the reported value with the untimed repeat against the same band,
unless the untimed repeat is itself more than 5 % above the fastest timed one (then V7 is not assessed for that run).

Bundles written since D-35 carry the verdict in summary.json (`repeat_rule`) and link re-measures in run.json; for
older bundles the verdict is computed here from the repeat medians and no re-measure exists. Also prints, per run,
the CoV of all repeats (the pre-D-35 V4 metric) and the untimed repeat against the fastest timed one.
Standard library only; other scripts import judge() and run_verdict() from here.
"""
import json
import statistics
import sys
from pathlib import Path

SLOW_FACTOR = 1.05
MIN_CLEAN = 3
LIGHT_FRAME_MS = 1.0
BAND_LIGHT = 0.02
BAND_HEAVY = 0.005


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def cov(xs):
    """Sample standard deviation over mean, as the harness computes it."""
    return statistics.stdev(xs) / statistics.mean(xs) if len(xs) > 1 and statistics.mean(xs) else 0.0


def judge(timed, factor=SLOW_FACTOR):
    """The D-35 verdict for a list of timed-repeat GPU frame medians (repeat order)."""
    fastest = min(timed)
    clean = [i for i, t in enumerate(timed) if t <= fastest * factor]
    values = [timed[i] for i in clean]
    value = statistics.median(values)
    c = cov(values)
    needs = len(clean) < min(MIN_CLEAN, len(timed))
    band = BAND_LIGHT if value < LIGHT_FRAME_MS else BAND_HEAVY
    return {"fastest_gpu_frame_ms": fastest, "flagged_repeats": [i for i in range(len(timed)) if i not in clean],
            "clean_repeats": len(clean), "clean_indices": clean, "gpu_frame_ms": value, "gpu_frame_ms_cov_clean": c,
            "max_over_median": max(timed) / statistics.median(timed), "v4_band": band,
            "v4_pass": c < band and not needs, "needs_remeasure": needs}


def summary_verdict(s):
    """Verdict for one summary.json: the harness's own when present, else computed. Adds per-pass clean medians and
    the V7 comparison."""
    timed = [x for x in s["repeats"] if x.get("timed")]
    medians = [x["gpu_frame_ms"]["median"] for x in timed]
    a = s["across_repeats"]
    stored = a.get("repeat_rule")
    v = judge(medians, stored["slow_factor"] if stored else SLOW_FACTOR)
    if stored:
        v.update({k: stored[k] for k in v if k in stored})
    v["source"] = "bundle" if stored else "computed"
    v["timed_ms"] = medians
    v["cov_all"] = cov(medians)
    v["passes_ms"] = {}
    for name, p in a.get("passes_ms", {}).items():
        if "median_of_clean" in p:
            v["passes_ms"][name] = p["median_of_clean"]
        else:
            per = [timed[i].get("passes_ms", {}).get(name, {}).get("median") for i in v["clean_indices"]]
            per = [x for x in per if x is not None]
            if per:
                v["passes_ms"][name] = statistics.median(per)
    t = a.get("timer_overhead")
    if t:
        u = t["untimed_gpu_frame_ms_median"]
        slow = t.get("untimed_slow", u > v["fastest_gpu_frame_ms"] * SLOW_FACTOR)
        ratio = v["gpu_frame_ms"] / u if u > 0 else 0.0
        v.update({"untimed_ms": u, "untimed_slow": slow, "ratio_clean": ratio,
                  "fastest_over_untimed": v["fastest_gpu_frame_ms"] / u if u > 0 else 0.0,
                  "v7_pass": t.get("v7_pass", None if slow else abs(ratio - 1.0) < v["v4_band"])})
    return v


def run_verdict(bundle: Path, run_entry: dict):
    """The verdict to report for one run.json run entry: its re-measure when it has one."""
    first = summary_verdict(load(bundle / run_entry["dir"].replace("\\", "/") / "summary.json"))
    re = run_entry.get("remeasure")
    if re:
        v = summary_verdict(load(bundle / re["dir"].replace("\\", "/") / "summary.json"))
        v.update({"remeasured": True, "first": first, "dir": re["dir"]})
    else:
        v = dict(first)
        v.update({"remeasured": False, "dir": run_entry["dir"]})
    # A bundle that predates D-35 could not re-measure: say so rather than count the run as re-measured.
    v["remeasure_missing"] = v["needs_remeasure"] and not re and first["source"] == "computed"
    v["unstable"] = v["needs_remeasure"]
    return v


def runs(bundle: Path):
    for wl in load(bundle / "run.json").get("workloads", []):
        for r in wl.get("runs", []):
            name = wl["id"] if r["value"] == "fixed" else f"{wl['id']}/{r['value']}"
            yield wl, r, name


def analyse(bundle: Path):
    out = []
    for wl, r, name in runs(bundle):
        v = run_verdict(bundle, r)
        v["run"] = name
        v["workload"] = wl["id"]
        out.append(v)
    return out


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        print(__doc__)
        return 2
    result = {Path(b).name: analyse(Path(b)) for b in args}
    if "--json" in sys.argv:
        print(json.dumps(result, indent=1))
        return 0
    for bundle, rows in result.items():
        print(f"# {bundle} (verdicts {rows[0]['source'] if rows else '-'})")
        print(f"{'run':<14}{'value':>9}{'max/med':>9}{'flag':>5}{'CoV all':>9}{'CoV ok':>8}{'band':>6}{'V4':>5}"
              f"{'untimed':>9}{'val/unt':>9}{'fast/unt':>9}{'V7':>5}  note")
        for v in rows:
            v7 = {True: "pass", False: "FAIL", None: "-"}[v.get("v7_pass")]
            u = (f"{v['untimed_ms']:>9.3f}{v['ratio_clean']:>9.3f}{v['fastest_over_untimed']:>9.3f}{v7:>5}"
                 if "untimed_ms" in v else " " * 32)
            note = []
            if v["remeasured"]:
                note.append(f"re-measured (first: {v['first']['clean_repeats']} clean)")
            if v["remeasure_missing"]:
                note.append("needs a re-measure (bundle predates D-35)")
            elif v["unstable"]:
                note.append("unstable")
            if v.get("untimed_slow"):
                note.append("untimed slow: V7 not assessed")
            print(f"{v['run']:<14}{v['gpu_frame_ms']:>9.3f}{v['max_over_median']:>9.3f}{len(v['flagged_repeats']):>5}"
                  f"{v['cov_all'] * 100:>8.2f}%{v['gpu_frame_ms_cov_clean'] * 100:>7.2f}%{v['v4_band'] * 100:>5.1f}%"
                  f"{'pass' if v['v4_pass'] else 'FAIL':>5}{u}  {'; '.join(note)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
