#!/usr/bin/env python3
"""Numbers and tables for the MethodsX draft, computed from result bundles only (docs/MANUSCRIPT.md:
no number is typed by hand).

Usage: paper_data.py [--sources paper/data_sources.json] [--out paper/generated]

`data_sources.json` maps roles to bundle directories (null = not measured yet) and marks bundles that are
provisional. Writes to --out:
  values.json             every key with its value, source bundle and provisional flag
  tables.md               the tables the draft asks for, as Markdown
  manuscript.filled.md    paper/manuscript.md with each `[[DATA: <key> ...]]` (key: lower case with an underscore) whose key is known replaced
                          by its value; values from provisional bundles carry a "(provisional)" mark.
                          Unknown keys stay as placeholders. The source draft is never modified.
Standard library only. Re-uses sustained.py for the D-31 steady-state rule.
"""
import datetime
import json
import math
import re
import statistics
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import sustained as sus  # noqa: E402  (D-31 reference rule, shared with sustained.py)
import scaling  # noqa: E402  (expected pass and shape per workload, V6)
import repeat_spread as d35  # noqa: E402  (D-35 slow-repeat rule, shared with the harness)

ROOT = Path(__file__).resolve().parents[2]
# [[DATA: key]] or [[DATA: key: description]]; for a figure or table the description is its caption.
PLACEHOLDER = re.compile(r"\[\[DATA:\s*([a-z0-9]+_[a-z0-9_]+)\b\s*(?::\s*([^\]]*?))?\s*\]\]")


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def utc(s: str) -> datetime.datetime:
    return datetime.datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ")


def label(wl_id: str, value: str) -> str:
    return wl_id if value == "fixed" else f"{wl_id}/{value}"


def runs(bundle: Path):
    """Yields (workload entry, run entry, summary) in suite order."""
    for wl in load(bundle / "run.json").get("workloads", []):
        for r in wl.get("runs", []):
            yield wl, r, load(bundle / r["dir"].replace("\\", "/") / "summary.json")


def pct(x: float, digits: int = 2) -> str:
    return f"{x * 100:.{digits}f} %"


class Values:
    def __init__(self):
        self.items = {}

    def put(self, key, text, source, provisional, data=None):
        self.items[key] = {"text": text, "source": source, "provisional": provisional, "data": data}


def add_table(v: Values, tables: list, t: list, src: str, prov: bool):
    """t[0] is the table key, the rest its Markdown rows; the table is also a fillable value."""
    body = "\n".join(t[1:])
    v.put(t[0], body, src, prov)
    tables.append(f"### {t[0]} ({src}{', provisional' if prov else ''})\n\n{body}")


def suite_values(v: Values, bundle: Path, prov: bool, tag: str, tables: list):
    run = load(bundle / "run.json")
    src = bundle.name
    minutes = (utc(run["finished_utc"]) - utc(run["started_utc"])).total_seconds() / 60.0
    v.put(f"suite_duration_{tag}", f"{minutes:.0f} min", src, prov, minutes)

    rows = list(runs(bundle))
    verdicts = [d35.run_verdict(bundle, r) for _, r, _ in rows]
    # V4 (D-35): CoV of the clean repeats against a band of 2 % for frames under 1 ms and 0.5 % otherwise; a run
    # with too few clean repeats fails unless its re-measure has enough. The first workload (all its sweep values)
    # opens the session and C1 is the composite after the whole suite: both are reported apart.
    named = [(wl["id"], label(wl["id"], r["value"]), s, v) for (wl, r, s), v in zip(rows, verdicts)]
    first_id = named[0][0]
    preheated = named[0][2].get("preheat_s", 0) > 0
    first = [(n, s["across_repeats"]["gpu_frame_ms_cov_between_repeats"]) for i, n, s, _ in named if i == first_id]
    isolated = [(n, s, v) for i, n, s, v in named if i != first_id and not i.startswith("C")]
    composite = [(n, v) for i, n, _, v in named if i != first_id and i.startswith("C")]
    typical = statistics.median(s["across_repeats"]["gpu_frame_ms_cov_between_repeats"] for _, s, _ in isolated)
    first_text = ", ".join(f"{pct(c, 1)} ({n})" for n, c in first)
    v.put(f"preheat_cov_{tag}", f"{first_text} in the first workload, against a median of {pct(typical)} in the later "
          f"isolated workloads", src, prov, {"first": first, "median_isolated": typical})

    def band_text(x):
        return f"{pct(x['gpu_frame_ms_cov_clean'])} (band {pct(x['v4_band'], 1)})"
    def fail_text(n, x):
        if x["unstable"]:
            return (f"{n} only {x['clean_repeats']} of {len(x['timed_ms'])} repeats clean, "
                    + ("a re-measure this bundle predates" if x["remeasure_missing"] else "also after its re-measure"))
        return f"{n} {band_text(x)}"
    failed = [fail_text(n, x) for n, _, x in isolated if not x["v4_pass"]]
    flagged_runs = [n for n, _, x in isolated if x["flagged_repeats"] or x["remeasured"]]
    flagged_reps = sum(len(x["flagged_repeats"]) + (len(x["first"]["flagged_repeats"]) if x["remeasured"] else 0)
                       for _, _, x in isolated)
    total_reps = sum(len(x["timed_ms"]) + (len(x["first"]["timed_ms"]) if x["remeasured"] else 0) for _, _, x in isolated)
    remeasured = [n for n, _, x in isolated if x["remeasured"]]
    first_v = [(n, x) for i, n, _, x in named if i == first_id]
    def first_text_of(n, x):
        verdict = "pass" if x["v4_pass"] else "fail"
        if x["remeasured"]:
            f = x["first"]
            return (f"{n} {len(f['flagged_repeats'])} of {len(f['timed_ms'])} repeats flagged, re-measured at the end of "
                    f"the suite: {len(x['flagged_repeats'])} of {len(x['timed_ms'])} flagged, {verdict}")
        return f"{n} {len(x['flagged_repeats'])} of {len(x['timed_ms'])} repeats flagged, {verdict}"
    first_d35 = "; ".join(first_text_of(n, x) for n, x in first_v)
    v.put(f"v4_{tag}", f"the clean repeats stay within the band for {len(isolated) - len(failed)} of {len(isolated)} "
          f"isolated runs after the first workload" + (f" (outside: {'; '.join(failed)})" if failed else "")
          + (f"; slow repeats were flagged in {len(flagged_runs)} runs ({flagged_reps} of {total_reps} repeats)" if flagged_reps
             else f"; no repeat was flagged as slow (0 of {total_reps})")
          + (f", and {len(remeasured)} runs were re-measured ({', '.join(remeasured)})" if remeasured else "")
          + f"; first workload ({'after' if preheated else 'before'} the pre-heat): {first_d35}"
          + "".join(f"; {n} {band_text(x)}, {len(x['flagged_repeats'])} repeats flagged" for n, x in composite),
          src, prov, {"failed": failed, "flagged_runs": flagged_runs, "remeasured": remeasured})

    # Slow repeats in the isolated runs: which runs, how slow against the fastest repeat, and their frame length
    # (a re-measured run contributes its first measurement and the re-measure).
    slow_runs = []
    for n, _, x in isolated:
        for y in ([x["first"]] if x["remeasured"] else []) + [x]:
            if y["flagged_repeats"]:
                worst = max(y["timed_ms"][i] for i in y["flagged_repeats"]) / y["fastest_gpu_frame_ms"]
                slow_runs.append((n, len(y["flagged_repeats"]), len(y["timed_ms"]), worst, y["gpu_frame_ms"]))
    if slow_runs:
        frames = [f for *_, f in slow_runs]
        slow_text = (f"{len(set(n for n, *_ in slow_runs))} of {len(isolated)} isolated runs had slow repeats (count of "
                     f"{slow_runs[0][2]}, and the slowest against the fastest repeat): "
                     + ", ".join(f"{n} ({k}, {w:.2f}×)" for n, k, m, w, _ in slow_runs)
                     + f"; their clean frame medians are {min(frames):.2f} to {max(frames):.2f} ms")
    else:
        slow_text = f"none of the {len(isolated)} isolated runs had a slow repeat"
    v.put(f"slow_repeats_{tag}", slow_text, src, prov, slow_runs)

    # V7 (D-35): the reported value against the untimed repeat, within the run's V4 band; not assessed where the
    # untimed repeat itself was more than 5 % above the fastest timed repeat.
    assessed = [(label(wl["id"], r["value"]), x) for (wl, r, _), x in zip(rows, verdicts) if x.get("v7_pass") is not None]
    slow = [label(wl["id"], r["value"]) for (wl, r, _), x in zip(rows, verdicts) if "untimed_ms" in x
            and x.get("v7_pass") is None]
    within = [x["ratio_clean"] for _, x in assessed if x["v7_pass"]]
    outside = [f"{n} {x['ratio_clean']:.3f}" for n, x in assessed if not x["v7_pass"]]
    if outside and all(x["ratio_clean"] < 1.0 for _, x in assessed if not x["v7_pass"]):
        outside[-1] += " (in each, the untimed repeat was the slower one)"
    v.put(f"v7_overhead_{tag}", f"reported value / untimed repeat {min(within):.3f} to {max(within):.3f} for "
          f"{len(within)} of {len(assessed)} assessed runs" + (f"; outside the band: {', '.join(outside)}" if outside else "")
          + (f"; not assessed, untimed repeat itself slow: {', '.join(slow)}" if slow else ""), src, prov)
    # D-41: the timestamp cost per timed pass, (timed - untimed frame median) / number of timed passes
    cost = sorted(sm["across_repeats"]["timer_overhead"]["difference_ms"] * 1000.0 / len(sm["across_repeats"]["passes_ms"])
                  for _, _, sm in rows
                  if sm["across_repeats"].get("timer_overhead") and sm["across_repeats"].get("passes_ms"))
    if len(cost) >= 2:
        q = statistics.quantiles(cost, n=4)
        v.put(f"v7_cost_{tag}", f"timed minus untimed frame time {statistics.median(cost):.1f} µs per timed pass "
              f"(median of {len(cost)} runs, quartiles {q[0]:.1f} to {q[2]:.1f} µs); outside the band in "
              f"{len(outside)} of {len(assessed)} assessed runs", src, prov,
              {"median_us": statistics.median(cost), "quartiles_us": [q[0], q[2]], "runs": len(cost)})
    serialized = all(wl.get("protocol", {}).get("passes_serialized", False) for wl, _, _ in rows)
    if serialized:
        res = []
        for wl, r, s in rows:
            timed = [x for x in s["repeats"] if x.get("timed") and "residual_ms" in x]
            if timed:
                res.append((label(wl["id"], r["value"]), statistics.median(x["residual_ms"]["median"] for x in timed),
                            s["across_repeats"]["gpu_frame_ms_median_of_repeats"]))
        worst_rel = max(res, key=lambda x: abs(x[1]) / x[2])
        v.put(f"v7_residual_{tag}", f"largest residual {worst_rel[1]:.4f} ms ({pct(abs(worst_rel[1]) / worst_rel[2])} of the "
              f"frame, {worst_rel[0]})", src, prov)
    else:
        v.put(f"v7_residual_{tag}", "not valid: passes overlapped in this bundle (before D-30)", src, prov)

    # V3 from checks.json.
    checks = load(bundle / "checks.json") if (bundle / "checks.json").exists() else {}
    v3 = checks.get("v3", [])
    if v3:
        passed = [c for c in v3 if c["pass"]]
        # Reports since O-17 gate on interior pixels and count depth-edge pixels; older ones gate on all both-hit pixels.
        gate = lambda c: c.get("agree_fraction_interior", c["agree_fraction_of_both_hit"])
        edge_gated = all("agree_fraction_interior" in c for c in v3)
        failed = [f"{label(c['workload'], c['value'])} {gate(c):.4f}" for c in v3 if not c["pass"]]
        v.put(f"v3_{tag}", f"{len(passed)} of {len(v3)} checks pass" + (f"; failing: {', '.join(failed)}" if failed else "")
              + ("" if edge_gated else " (all both-hit pixels gated; bundle predates the depth-edge rule)"), src, prov)
        if edge_gated:
            t = [f"tab_v3_{tag}", "| Workload | Agreement (interior) | Agreement (all both hit) | Depth-edge pixels "
                 "(disagreeing) | Coverage mismatch | Pass |", "|---|---|---|---|---|---|"]
            t += [f"| {label(c['workload'], c['value'])} | {c['agree_fraction_interior']:.5f} | "
                  f"{c['agree_fraction_of_both_hit']:.5f} | {c['edge_fraction_of_both_hit'] * 100:.1f} % "
                  f"({c['edge_disagree']}) | {c['coverage_mismatch_fraction']:.6f} | {'yes' if c['pass'] else 'no'} |"
                  for c in v3]
        else:
            t = [f"tab_v3_{tag}", "| Workload | Agreement (both hit) | Coverage mismatch | Pass |", "|---|---|---|---|"]
            t += [f"| {label(c['workload'], c['value'])} | {c['agree_fraction_of_both_hit']:.5f} | "
                  f"{c['coverage_mismatch_fraction']:.6f} | {'yes' if c['pass'] else 'no'} |" for c in v3]
        add_table(v, tables, t, src, prov)

    # Workload table: scene size from as.json, GPU frame time, CoV.
    # Workload table: scene size from as.json; GPU frame time and CoV of the clean repeats (D-35).
    t = [f"tab_workloads_{tag}",
         "| Run | Resolution | BLAS triangles | TLAS instances | GPU frame (ms) | CoV (clean repeats) | Flagged |",
         "|---|---|---|---|---|---|---|"]
    for (wl, r, s), x in zip(rows, verdicts):
        a = load(bundle / r["dir"].replace("\\", "/") / "as.json") if (bundle / r["dir"].replace("\\", "/") / "as.json").exists() else {}
        tris = sum(b.get("triangles", 0) for b in a.get("blas", []))
        inst = a.get("tlas", {}).get("instances")
        note = " (re-measured)" if x["remeasured"] else " (re-measure missing)" if x["remeasure_missing"] else ""
        t.append(f"| {label(wl['id'], r['value'])} | {s['width']}×{s['height']} | {tris or '–'} | {inst or '–'} | "
                 f"{x['gpu_frame_ms']:.3f} | {pct(x['gpu_frame_ms_cov_clean'])} | "
                 f"{len(x['flagged_repeats'])} of {len(x['timed_ms'])}{note} |")
    add_table(v, tables, t, src, prov)

    # Mrays/s per ray-tracing pass, from the pass median over the clean repeats (D-35). D-37: the zero-ray floor of
    # the same workload (its value with ray tracing off; a resolution sweep has one per value) and the throughput of
    # the part above it.
    floors = {(wl["id"], s.get("floor_of", "")): x["passes_ms"] for (wl, r, s), x in zip(rows, verdicts)
              if r["value"].startswith("floor")}
    t = [f"tab_mrays_{tag}", "| Run | Pass | Median (ms) | Floor (ms) | Rays per frame | Mrays/s | Mrays/s above "
         "floor | Ray count |", "|---|---|---|---|---|---|---|---|"]
    mrays = []  # per run and pass, for the cross-device table (tab_mrays_devices)
    for (wl, r, s), x in zip(rows, verdicts):
        if r["value"].startswith("floor"):
            continue
        first = wl.get("runs", [{}])[0].get("value", "")
        fl_run = floors.get((wl["id"], r["value"])) or floors.get((wl["id"], first)) or {}
        for name, p in s["across_repeats"].get("passes_ms", {}).items():
            med = x["passes_ms"].get(name)
            if "rays_per_frame" in p and med and p["rays_per_frame"] > 0:
                fl = fl_run.get(name)
                above = f"{p['rays_per_frame'] / ((med - fl) * 1.0e3):.0f}" if fl is not None and med > fl else "–"
                mrays.append({"run": label(wl["id"], r["value"]), "pass": name, "rays_per_frame": p["rays_per_frame"],
                              "mrays": p["rays_per_frame"] / (med * 1.0e3),
                              "mrays_above_floor": float(above) if above != "–" else None})
                t.append(f"| {label(wl['id'], r['value'])} | {name} | {med:.3f} | "
                         f"{f'{fl:.3f}' if fl is not None else '–'} | {p['rays_per_frame']:.0f} | "
                         f"{p['rays_per_frame'] / (med * 1.0e3):.0f} | {above} | {p.get('rays_method', '')} |")
    add_table(v, tables, t, src, prov)
    v.put(f"mrays_{tag}", f"{len(mrays)} ray-tracing passes", src, prov, mrays)
    # The floors in words: each effect pass of each floor run against the same pass with rays at that value.
    parts = []
    for (wl, r, s), x in zip(rows, verdicts):
        if not r["value"].startswith("floor"):
            continue
        of = s.get("floor_of", "")
        ref = next((xx for (w2, rr, _), xx in zip(rows, verdicts) if w2["id"] == wl["id"] and rr["value"] == of), None)
        for name, fl in x["passes_ms"].items():
            if "rays" not in name:
                continue
            with_rays = ref["passes_ms"].get(name) if ref else None
            parts.append(f"{wl['id']} {name.replace(' rays', '')} {fl:.3f} ms"
                         + (f" ({pct(fl / with_rays, 0)} of {with_rays:.3f} ms at {of})" if with_rays else ""))
    if parts:
        v.put(f"floor_{tag}", "; ".join(parts), src, prov)


def scaling_values(v: Values, bundle: Path, prov: bool, tag: str, tables: list):
    """V6 from scaling.py --json: does each sweep's pass time follow the parameter it claims to isolate?"""
    with tempfile.TemporaryDirectory() as d:
        out = Path(d) / "s.json"
        subprocess.run([sys.executable, str(Path(__file__).with_name("scaling.py")), str(bundle), "--json", str(out)],
                       check=True, capture_output=True)
        report = [e for e in load(out) if "correlation" in e]
    src = bundle.name

    def ratio(x):
        return f"{x:.2f}" if math.isfinite(x) else "–"
    # Monotonic rise is the one shape every expectation in scaling.EXPECTED shares; the table gives the rest.
    flat = [e for e in report if any(b < a for a, b in zip(e["pass_ms"], e["pass_ms"][1:]))]
    v.put(f"v6_{tag}", f"pass time does not fall as the swept parameter rises in {len(report) - len(flat)} of "
          f"{len(report)} sweeps" + ("; not monotonic: " + ", ".join(
              f"{e['workload']} (last/first ×{ratio(e['time_ratio_last_first'])}"
              + (f" for parameter ×{ratio(e['parameter_ratio_last_first'])}" if math.isfinite(e["parameter_ratio_last_first"]) else "")
              + ")" for e in flat) if flat else ""), src, prov, report)
    t = [f"tab_v6_{tag}", "| Workload | Pass | Expected | Sweep | Time ratio last/first | Parameter ratio | r |",
         "|---|---|---|---|---|---|---|"]
    t += [f"| {e['workload']} | {e['pass']} | {e['expected']} | {', '.join(e['values'])} | "
          f"{ratio(e['time_ratio_last_first'])} | {ratio(e['parameter_ratio_last_first'])} | {e['correlation']:.3f} |"
          for e in report]
    add_table(v, tables, t, src, prov)


def device_row(bundle: Path) -> str:
    """One row of tab_devices from system.json and run.json. The host name is left out (personal data)."""
    sysj, run = load(bundle / "system.json"), load(bundle / "run.json")
    build = run.get("shader_build", {})
    compiler = build.get("metal_compiler") if sysj["backend"] == "metal" else \
        sysj.get("driver_version", sysj["api_version"].split(", ", 1)[-1])
    mem = f"{sysj['memory_bytes'] / 2 ** 30:.0f} GB" + (" unified" if sysj.get("unified_memory") else "")
    session = run.get("started_utc", "")[:10]
    fingerprint = build.get("artifacts", {}).get("fnv1a64", "–")
    return (f"| {sysj['device_name']} | {session} | {sysj['api_version']} | "
            f"{os_text(sysj)} | "
            f"{compiler} | Slang {build.get('slang_version', '–')} | {mem} | {sysj['gpu_timer_method']} | "
            f"{sysj['power_source']}, {sysj['power_mode']}{adapter_note(sysj)} | {run['engine_commit']}, {fingerprint} |")


def os_text(sysj: dict) -> str:
    if sysj["os"].startswith("Windows"):
        # RtlGetVersion reports 10.0 for Windows 11 too; builds from 22000 are Windows 11
        build = int(sysj["os"].rsplit(" ", 1)[-1])
        return f"Windows {11 if build >= 22000 else 10} (build {build})"
    return sysj["os_version"].replace("Version ", sysj["os"].split(" ")[0] + " ")


def device_of(bundle: Path) -> str:
    return load(bundle / "system.json")["device_name"]


def adapter_note(sysj: dict) -> str:
    """Adapter rating from system.json (O-18); bundles older than O-18 did not record it."""
    ps = sysj.get("power_state")
    if ps is None:
        return ", adapter not recorded"
    if not ps.get("battery"):
        return ""
    return f", {ps['adapter_watts']} W adapter" if ps.get("adapter_watts") is not None else ", adapter unknown"


def sustained_json(bundle: Path) -> dict:
    """sustained.py's D-31 analysis of one sustained bundle."""
    with tempfile.TemporaryDirectory() as d:
        out = Path(d) / "s.json"
        subprocess.run([sys.executable, str(Path(__file__).with_name("sustained.py")), str(bundle), "--json", str(out)],
                       check=True, capture_output=True)
        return load(out)


def parity_values(v: Values, ref: Path, bundle: Path, prov: bool, tag: str):
    """v1_<tag>, v2_<tag>: compare_bundles.py's V1/V2 of a suite against the reference suite (D-19 thresholds)."""
    with tempfile.TemporaryDirectory() as d:
        out = Path(d) / "c.json"
        subprocess.run([sys.executable, str(Path(__file__).with_name("compare_bundles.py")), str(ref), str(bundle),
                        "--json", str(out)], check=False, capture_output=True)
        report = load(out)
    src = f"{ref.name}, {bundle.name}"
    frames = [f for e in report for f in e["frames"] if "error" not in f]
    failed = [f"{e['workload']}/{e['value']} frame {f['frame']}" for e in report for f in e["frames"]
              if not f.get("pass")]
    worst = max(frames, key=lambda f: f["fraction_over_2"])
    v.put(f"v1_{tag}", f"{len(frames) - len(failed)} of {len(frames)} reference frames within the gate "
          f"({sum(f['identical'] for f in frames)} identical); largest fraction over 2/255 "
          f"{pct(worst['fraction_over_2'], 4)}, largest mean difference {max(f['mean_abs'] for f in frames):.4f}"
          + (f"; failing: {', '.join(failed)}" if failed else ""), src, prov,
          {"frames": len(frames), "failed": failed, "worst_fraction_over_2": worst["fraction_over_2"]})
    rays = [(e["workload"], e["value"], r) for e in report for r in e["rays"]]
    off = [(w, val, r) for w, val, r in rays if r["ratio"] != 1.0]
    worst_r = max(rays, key=lambda x: abs(x[2]["ratio"] - 1.0))
    near = len([x for x in off if abs(x[2]["ratio"] - 1.0) <= 0.001])
    v.put(f"v2_{tag}", f"rays per frame equal in {len(rays) - len(off)} of {len(rays)} passes and within 0.1 % in {near} "
          f"more; largest difference "
          f"{pct(abs(worst_r[2]['ratio'] - 1.0))} ({worst_r[0]}/{worst_r[1]} {worst_r[2]['pass']})"
          + (f"; outside 1 %: {len([x for x in rays if not x[2]['ok']])}" if any(not x[2]["ok"] for x in rays) else ""),
          src, prov, {"passes": len(rays), "unequal": len(off), "worst_ratio": worst_r[2]["ratio"]})
    return report


PARITY_PANELS = ["W1", "W2", "W4", "W6", "W10", "C1"]  # one per ray-traced effect, and the composite


def fig_parity(ref: Path, bundle: Path, report: list, prov: bool, out_path: Path):
    """V1 across devices: for each effect, the reference frame with the most pixels over 2/255, drawn as a coarse
    grey thumbnail of the reference image with every such pixel marked."""
    import compare_bundles as cb
    _, runs_a = cb.runs_of(ref)
    _, runs_b = cb.runs_of(bundle)
    picks = []
    for wid in PARITY_PANELS:
        cand = [(f["fraction_over_2"], e["value"], f["frame"]) for e in report if e["workload"] == wid
                for f in e["frames"] if "error" not in f and not e["value"].startswith("floor")]
        if cand:
            picks.append((wid,) + max(cand)[1:])
    cols, pw, ph, gap, top = 3, 300, 169, 26, 64
    rows_n = (len(picks) + cols - 1) // cols
    W, H = cols * pw + (cols + 1) * gap, top + rows_n * (ph + 58) + 20
    ink, muted, red = "#0b0b0b", "#52514e", "#c8372d"
    names = [load(b / "system.json")["device_name"] for b in (ref, bundle)]
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" '
           f'font-family="Helvetica, Arial, sans-serif" font-size="11" fill="{ink}">',
           f'<rect width="{W}" height="{H}" fill="#ffffff"/>',
           f'<text x="{gap}" y="22" font-size="13" font-weight="bold">V1 image parity: {names[0]} (Metal) against '
           f'{names[1]} (Vulkan)</text>',
           f'<text x="{gap}" y="40" fill="{muted}">thumbnail of the {names[0]} frame; red: pixels differing by more '
           f'than 2/255 in any channel (marks enlarged)</text>']
    for i, (wid, value, frame) in enumerate(picks):
        ra, rb = runs_a[(wid, value)][1], runs_b[(wid, value)][1]
        fa = {x["frame"]: x["file"] for x in ra["reference_frames"]}[frame]
        fb = {x["frame"]: x["file"] for x in rb["reference_frames"]}[frame]
        w, h, pa = cb.decode_png((ref / ra["dir"].replace("\\", "/") / fa).read_bytes())
        _, _, pb = cb.decode_png((bundle / rb["dir"].replace("\\", "/") / fb).read_bytes())
        x0 = gap + (i % cols) * (pw + gap)
        y0 = top + (i // cols) * (ph + 58)
        sh = pw * h / w
        gx, gy = 48, max(1, round(48 * h / w))
        cw, ch = pw / gx, sh / gy
        for by in range(gy):
            for bx in range(gx):
                acc, n = 0, 0
                for yy in range(by * h // gy, (by + 1) * h // gy, 4):
                    row = yy * w
                    for xx in range(bx * w // gx, (bx + 1) * w // gx, 4):
                        o = (row + xx) * 4
                        acc += 0.2126 * pa[o] + 0.7152 * pa[o + 1] + 0.0722 * pa[o + 2]
                        n += 1
                lum = round(150 + (acc / n) * 95 / 255) if n else 245  # compressed to light greys, marks stay visible
                out.append(f'<rect x="{x0 + bx * cw:.1f}" y="{y0 + by * ch:.1f}" width="{cw + 0.3:.1f}" '
                           f'height="{ch + 0.3:.1f}" fill="rgb({lum},{lum},{lum})"/>')
        over, worst = [], 0
        for k in range(w * h):
            o = k * 4
            m = max(abs(pa[o] - pb[o]), abs(pa[o + 1] - pb[o + 1]), abs(pa[o + 2] - pb[o + 2]))
            if m > 2:
                over.append(k)
                worst = max(worst, m)
        for k in over:
            out.append(f'<circle cx="{x0 + (k % w + 0.5) * pw / w:.1f}" cy="{y0 + (k // w + 0.5) * sh / h:.1f}" r="2.2" '
                       f'fill="{red}"/>')
        out.append(f'<rect x="{x0}" y="{y0}" width="{pw}" height="{sh:.1f}" fill="none" stroke="{muted}"/>')
        out.append(f'<text x="{x0}" y="{y0 + sh + 16:.1f}" font-weight="bold">{label(wid, value)}, frame {frame}</text>')
        out.append(f'<text x="{x0}" y="{y0 + sh + 31:.1f}" fill="{muted}">{len(over)} of {w * h} pixels over 2/255 '
                   f'({pct(len(over) / (w * h), 4)}), largest {worst}/255</text>')
    if prov:
        out.append(f'<text x="{W - gap}" y="{H - 8}" text-anchor="end" fill="{muted}">provisional data</text>')
    out.append("</svg>")
    out_path.write_text("\n".join(out) + "\n", encoding="utf-8")


def mrays_devices(v: Values, tables: list, ref_tag: str, tags: list, names: dict, src: str, prov: bool):
    """tab_mrays_devices and mrays_ratio_<tag>: Mrays/s per run and pass on each device, and each device against the
    reference device. Only runs and passes present on every device enter, so the ratios compare the same work."""
    per = {t: {(e["run"], e["pass"]): e for e in v.items[f"mrays_{t}"]["data"]} for t in [ref_tag] + tags}
    keys = [k for k in per[ref_tag] if all(k in per[t] for t in tags)]
    head = "| Run | Pass | " + " | ".join(f"{names[t]} Mrays/s" for t in [ref_tag] + tags) + " | " + \
        " | ".join(f"{names[t]} / {names[ref_tag]} (above floor)" for t in tags) + " |"
    t = ["tab_mrays_devices", head, "|" + "---|" * (2 + 1 + 2 * len(tags))]
    for k in keys:
        a = per[ref_tag][k]
        cells = [f"{per[x][k]['mrays']:.0f}" for x in [ref_tag] + tags]
        for x in tags:
            b = per[x][k]
            above = (f"{b['mrays_above_floor'] / a['mrays_above_floor']:.1f}"
                     if a["mrays_above_floor"] and b["mrays_above_floor"] else "–")
            cells.append(f"{b['mrays'] / a['mrays']:.1f} ({above})")
        t.append(f"| {k[0]} | {k[1]} | " + " | ".join(cells) + " |")
    add_table(v, tables, t, src, prov)
    for x in tags:
        ratios = sorted((per[x][k]["mrays"] / per[ref_tag][k]["mrays"], k) for k in keys)
        above = sorted((per[x][k]["mrays_above_floor"] / per[ref_tag][k]["mrays_above_floor"], k) for k in keys
                       if per[ref_tag][k]["mrays_above_floor"] and per[x][k]["mrays_above_floor"])
        text = (f"{names[x]} against {names[ref_tag]}: {ratios[0][0]:.1f}× ({ratios[0][1][0]} {ratios[0][1][1]}) to "
                f"{ratios[-1][0]:.1f}× ({ratios[-1][1][0]} {ratios[-1][1][1]}) the ray throughput over {len(ratios)} passes")
        if above:
            text += (f"; above the zero-ray floor {above[0][0]:.1f}× ({above[0][1][0]} {above[0][1][1]}) to "
                     f"{above[-1][0]:.1f}× ({above[-1][1][0]} {above[-1][1][1]}) over {len(above)} passes")
        v.put(f"mrays_ratio_{x}", text, src, prov,
              {"ratio": [r for r, _ in ratios], "above_floor": [r for r, _ in above]})


def sustained_values(v: Values, bundle: Path, prov: bool, tag: str, tables: list):
    s = sustained_json(bundle)
    src = bundle.name
    minutes = s["duration_s"] / 60.0
    steady = (f"steady from {s['time_to_steady_s']:.0f} s at {s['steady_to_burst_ratio']:.3f}× the burst frame time"
              if s["steady_detected"] else "frame time not steady")
    text = f"{minutes:.0f}-min run: burst {s['burst_gpu_frame_ms_median']:.3f} ms, {steady}"
    if "power" in s:
        p = s["power"]
        text += (f"; power {p['burst_mean_combined_mw'] / 1000:.1f} W burst, "
                 + (f"steady from {p['time_to_steady_s']:.0f} s at {p['steady_mean_combined_mw'] / 1000:.1f} W"
                    if p["steady_detected"] else f"not steady by {minutes:.0f} min"))
    v.put(f"v9_{tag}", text, src, prov, s)
    t = [f"tab_sustained_{tag}", "| Window start (s) | Median GPU frame (ms) | Ratio to burst | Mean power (W) |",
         "|---|---|---|---|"]
    for w in s["windows"]:
        pw = f"{w['mean_combined_mw'] / 1000:.2f}" if w.get("mean_combined_mw") else "–"
        r = f"{w['ratio_to_burst']:.3f}" if w["ratio_to_burst"] else "–"
        t.append(f"| {w['start_s']:.0f} | {w['median_gpu_frame_ms']:.3f} | {r} | {pw} |")
    add_table(v, tables, t, src, prov)


def repeat_spread_values(v: Values, tag: str, ref: Path, repeats: list, prov: bool):
    """v9_<tag>_spread: the reference sustained run and its repeats (same condition), as ranges."""
    runs = [ref] + repeats
    ss = [sustained_json(b) for b in runs]
    prints = {load(b / "run.json").get("shader_build", {}).get("artifacts", {}).get("fnv1a64") for b in runs}
    steady = [s for s in ss if s["steady_detected"]]

    def rng(xs, fmt):
        lo, hi = fmt(min(xs)), fmt(max(xs))
        return lo if lo == hi else f"{lo}–{hi}"
    text = (f"{len(runs)} runs on {len(prints)} shader build{'s' if len(prints) > 1 else ''}: burst "
            f"{rng([s['burst_gpu_frame_ms_median'] for s in ss], lambda x: f'{x:.3f}')} ms, ")
    text += (f"steady from {rng([s['time_to_steady_s'] for s in steady], lambda x: f'{x:.0f}')} s at "
             f"{rng([s['steady_to_burst_ratio'] for s in steady], lambda x: f'{x:.3f}')}× the burst frame time"
             if steady else "none steady")
    if len(steady) < len(ss):
        text += f" ({len(ss) - len(steady)} not steady)"
    v.put(f"v9_{tag}_spread", text, ", ".join(b.name for b in runs), prov,
          [{"bundle": b.name, "burst_ms": s["burst_gpu_frame_ms_median"], "time_to_steady_s": s["time_to_steady_s"],
            "steady_to_burst_ratio": s["steady_to_burst_ratio"]} for b, s in zip(runs, ss)])


# fig_sustained: one static SVG for print, two stacked panels on a shared time axis (frame time relative to the
# burst period, and SoC power), never a second y-axis. Categorical slots 1 and 2 of the dataviz default palette
# (validated: CVD dE 24.7); the cooled run is also dashed, so identity never rests on colour alone.
SERIES_STYLE = [("#2a78d6", ""), ("#eb6834", "6 4")]
REPEAT_STYLE = ("#2a78d6", 1.25, 0.45)  # repeats of the first run's condition: its colour, thin, faded, panel a only
BIN_S = 10.0


def c1_track_values(v: Values, suite: Path, sustained: dict, prov: bool, tag: str):
    """c1_track_<tag>: C1's repeat stretches against the same track frames in the sustained runs (O-21)."""
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from c1_track import analyse
    r = analyse(suite, list(sustained))
    timed = [x for x in r["repeats"] if x["timed"]]
    names = r["sustained"]
    labels = {b.name: lab for b, lab in sustained.items()}
    if r.get("full_track"):
        suite_ms = ", ".join(f"{x['gpu_median_ms']:.3f}" for x in timed)
        devs = [x["gpu_median_ms"] / r["whole_track"][n] - 1.0 for x in timed for n in names]
        lo, hi = (f"{d * 100:+.1f}".replace("-", "−") for d in (min(devs), max(devs)))
        text = (f"each repeat covers the whole {r['track_frames']}-frame track; the timed repeat medians are {suite_ms} ms "
                + (f"(CoV {pct(r['suite_repeat_cov'])}), against whole-track medians of "
                   + " and ".join(f"{r['whole_track'][n]:.3f} ms ({labels[n]})" for n in names)
                   + " in the burst periods of the sustained runs" if len(names) > 1 else
                   f"(CoV {pct(r['suite_repeat_cov'])}), against a whole-track median of "
                   f"{r['whole_track'][names[0]]:.3f} ms in the burst period of the sustained run")
                + f", {lo if lo == hi else lo + ' to ' + hi} %")
        v.put(f"c1_track_{tag}", text, ", ".join([suite.name] + names), prov, r)
        return
    ranges = ", ".join(f"{x['first_frame']}–{x['last_frame']}" for x in timed)
    suite_ms = ", ".join(f"{x['gpu_median_ms']:.2f}" for x in timed)
    runs = "; ".join(", ".join(f"{x['sustained_median_ms'][n]:.2f}" for x in timed) + f" ms {labels[n]}" for n in names)
    devs = [abs(x["ratio"][n] - 1.0) for x in timed for n in names]
    pattern = " and ".join(f"{r['heavy_to_light_sustained'][n]:.2f}" for n in names)
    diff = r["pass_difference_ms"]
    top = max(diff, key=diff.get)
    wholes = [f"{m:.2f}" for m in r["whole_track"].values()]
    whole = f"{wholes[0]} ms in both" if len(set(wholes)) == 1 else " and ".join(wholes) + " ms in the two"
    heavy = next(x for x in timed if x["repeat"] == r["heaviest_repeat"])["gpu_median_ms"]
    light = next(x for x in timed if x["repeat"] == r["lightest_repeat"])["gpu_median_ms"]
    text = (f"its five repeats covered track frames {ranges} at {suite_ms} ms (CoV {pct(r['suite_repeat_cov'], 1)}), "
            f"and the same frames in the burst periods of the sustained runs give the same pattern ({runs}; heaviest to "
            f"lightest stretch {r['heavy_to_light']:.2f} in the suite against {pattern} there, every stretch "
            f"{min(devs) * 100:.1f}–{max(devs) * 100:.1f} % slower in the sustained runs than in the suite), with the "
            f"{top.replace(' rays', '')} pass carrying {diff[top]:.2f} ms of the {heavy - light:.2f} ms between the "
            f"heaviest and the lightest stretch; the median over the whole track is {whole} sustained runs")
    v.put(f"c1_track_{tag}", text, ", ".join([suite.name] + names), prov, r)


def nice_step(raw):
    """Smallest 1, 2 or 5 times a power of ten that is at least raw."""
    mag = 10.0 ** math.floor(math.log10(raw)) if raw > 0 else 1.0
    return next(m * mag for m in (1, 2, 5, 10) if m * mag >= raw)


def binned(points, bin_s=BIN_S, agg=statistics.median):
    bins = {}
    for t, y in points:
        if t >= 0:
            bins.setdefault(int(t // bin_s), []).append(y)
    return [((k + 0.5) * bin_s, agg(v)) for k, v in sorted(bins.items())]


def fig_sustained(entries, out_path, repeats=()):
    """entries: [(name, bundle, provisional, steady_start_s or None, power steady start or None)]; repeats: bundles
    repeating the first entry's condition, drawn behind it in panel a."""
    reps = []
    for bundle in repeats:
        rows = sus.load_timeline(bundle)
        _, ref = sus.reference(rows)
        reps.append(binned([(t, g / ref[k]) for t, k, g in rows if k in ref]))
    series = []
    for name, bundle, prov, t_steady, _ in entries:
        rows = sus.load_timeline(bundle)
        _, ref = sus.reference(rows)
        ratio = binned([(t, g / ref[k]) for t, k, g in rows if k in ref])
        end = rows[-1][0]
        prow = sus.load_power(bundle)  # the power log outlasts the run; keep the run's span only
        power = binned([(t, c / 1000.0) for t, c, _ in prow if t <= end], agg=statistics.fmean) if prow else []
        series.append((name + (" (provisional)" if prov else ""), ratio, power, t_steady))
    W, L, R, PH, GAP, T = 720, 64, 150, 200, 56, 36 + (24 if len(series) > 1 else 0)
    H = T + 2 * PH + GAP + 50
    tmax = max(p[0] for _, r, pw, _ in series for p in r + pw + [q for rp in reps for q in rp]) + BIN_S / 2
    tmax = 60.0 * (int(tmax // 60.0) + (1 if tmax % 60.0 else 0))

    def sx(t):
        return L + t / tmax * (W - L - R)

    ink, muted, grid = "#0b0b0b", "#52514e", "#e4e3df"
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" '
           f'font-family="Helvetica, Arial, sans-serif" font-size="12" fill="{ink}">',
           f'<rect width="{W}" height="{H}" fill="#ffffff"/>']

    def panel(top, title, ylabel, values, fmt, zero):
        ys = [y for _, y in values] or [0.0, 1.0]
        step = nice_step((max(ys) - (0.0 if zero else min(ys))) / 4)
        lo = 0.0 if zero else step * math.floor(min(ys) / step)
        hi = step * math.ceil(max(ys) / step)

        def sy(y):
            return top + (1.0 - (y - lo) / (hi - lo)) * PH
        out.append(f'<text x="{L}" y="{top - 10}" font-weight="bold">{title}</text>')
        for k in range(int(round((hi - lo) / step)) + 1):
            y = lo + step * k
            out.append(f'<line x1="{L}" y1="{sy(y):.1f}" x2="{W - R}" y2="{sy(y):.1f}" stroke="{grid}"/>')
            out.append(f'<text x="{L - 6}" y="{sy(y) + 4:.1f}" text-anchor="end" fill="{muted}">{fmt(y)}</text>')
        out.append(f'<text x="14" y="{top + PH / 2}" text-anchor="middle" fill="{muted}" '
                   f'transform="rotate(-90 14 {top + PH / 2})">{ylabel}</text>')
        return sy

    sy1 = panel(T, "a  GPU frame time relative to the burst period", "ratio to burst",
                [p for s in series for p in s[1]] + [p for rp in reps for p in rp], lambda y: f"{y:.2f}", zero=False)
    sy2 = panel(T + PH + GAP, "b  SoC power (CPU + GPU, powermetrics)", "power (W)", [p for s in series for p in s[2]],
                lambda y: f"{y:.0f}", zero=True)
    bottom = T + 2 * PH + GAP
    for m in range(0, int(tmax // 60) + 1, max(1, int(tmax // 60) // 10)):
        x = sx(m * 60.0)
        out.append(f'<line x1="{x:.1f}" y1="{bottom}" x2="{x:.1f}" y2="{bottom + 4}" stroke="{muted}"/>')
        out.append(f'<text x="{x:.1f}" y="{bottom + 18}" text-anchor="middle" fill="{muted}">{m}</text>')
    out.append(f'<text x="{(L + W - R) / 2}" y="{bottom + 38}" text-anchor="middle" fill="{muted}">time since start (min); '
               f'{BIN_S:.0f}-s bins</text>')
    colour, width, alpha = REPEAT_STYLE
    for pts in reps:
        path = " ".join(f"{sx(t):.1f},{sy1(y):.1f}" for t, y in pts)
        out.append(f'<polyline points="{path}" fill="none" stroke="{colour}" stroke-width="{width}" '
                   f'stroke-opacity="{alpha}"/>')
    end_labels = {0: [], 1: []}       # per panel: (y, x, name) at each series' last point
    for i, (name, ratio, power, t_steady) in enumerate(series):
        colour, dash = SERIES_STYLE[i]
        d = f' stroke-dasharray="{dash}"' if dash else ""
        for p, (pts, sy) in enumerate(((ratio, sy1), (power, sy2))):
            if pts:
                path = " ".join(f"{sx(t):.1f},{sy(y):.1f}" for t, y in pts)
                out.append(f'<polyline points="{path}" fill="none" stroke="{colour}" stroke-width="2"{d}/>')
                lx, ly = pts[-1]
                end_labels[p].append((sy(ly) + 4, sx(lx) + 6, name.split(" (")[0]))
    for labels in end_labels.values():     # series that end close together get their labels pushed apart
        prev = None
        for y, x, name in sorted(labels):
            if prev is not None and y - prev < 14:
                y = prev + 14
            out.append(f'<text x="{x:.1f}" y="{y:.1f}" fill="{ink}">{name}</text>')
            prev = y
    for i, (name, ratio, power, t_steady) in enumerate(series):
        colour, dash = SERIES_STYLE[i]
        if t_steady is not None:
            x = sx(t_steady)
            out.append(f'<line x1="{x:.1f}" y1="{T}" x2="{x:.1f}" y2="{T + PH}" stroke="{colour}" stroke-width="1" '
                       f'stroke-dasharray="2 3"/>')
            out.append(f'<text x="{x + 4:.1f}" y="{T + 12 + 14 * i}" fill="{muted}">steady from {t_steady / 60:.0f} min</text>')
    if any(name.endswith("(provisional)") for name, *_ in series):
        out.append(f'<text x="{W - R}" y="{H - 8}" text-anchor="end" font-size="10" fill="{muted}">provisional data: '
                   f'see paper/data_sources.json</text>')
    ly = T - 22  # legend above panel a, only when there is more than one series to tell apart
    legend = [(name, *SERIES_STYLE[i], 2, 1) for i, (name, *_rest) in enumerate(series)]
    if reps:
        legend.append((f"{series[0][0].split(' (')[0]}, repeats", REPEAT_STYLE[0], "", *REPEAT_STYLE[1:]))
    for i, (name, colour, dash, width, alpha) in enumerate(legend if len(legend) > 1 else []):
        x = L + i * 190
        d = f' stroke-dasharray="{dash}"' if dash else ""
        out.append(f'<line x1="{x}" y1="{ly - 4}" x2="{x + 24}" y2="{ly - 4}" stroke="{colour}" stroke-width="{width}" '
                   f'stroke-opacity="{alpha}"{d}/>')
        out.append(f'<text x="{x + 30}" y="{ly}">{name}</text>')
    out.append("</svg>")
    out_path.write_text("\n".join(out) + "\n", encoding="utf-8")


# fig_scaling: small multiples, one panel per swept workload, the pass scaling.py names for it. Points are the
# median of repeat medians, whiskers the range of the repeat medians. Points whose V3 check failed in the same
# bundle are hollow: the method withholds their timings, so they are shown only as diagnostics.
LOG_X = {"W3", "W8", "W8refit", "W9", "W10"}


def fig_scaling(bundle, prov, out_path):
    run = load(bundle / "run.json")
    v3_failed = {(c["workload"], c["value"]) for c in (load(bundle / "checks.json").get("v3", [])
                                                        if (bundle / "checks.json").exists() else []) if not c["pass"]}
    panels = []
    for wl in run.get("workloads", []):
        wid = wl["id"]
        if wid not in scaling.EXPECTED:
            continue
        param, pass_name, expected = scaling.EXPECTED[wid]
        pts, floor_pts = [], []
        for r in wl.get("runs", []):
            s = load(bundle / r["dir"].replace("\\", "/") / "summary.json")
            p = s["across_repeats"].get("passes_ms", {}).get(pass_name)
            if p is None:
                continue
            if s["value"].startswith("floor"):  # D-37
                xf = scaling.numeric(s.get("floor_of", "")) / (1.0e6 if param == "resolution" else 1.0)
                floor_pts.append((xf, p["median_of_repeats"]))
                continue
            meds = [rep["passes_ms"][pass_name]["median"] for rep in s["repeats"]
                    if rep.get("timed") and pass_name in rep.get("passes_ms", {})]
            x = scaling.numeric(s["value"])
            if param == "resolution":
                x /= 1.0e6
            pts.append((x, p["median_of_repeats"], min(meds or [0]), max(meds or [0]), s["value"],
                        (wid, s["value"]) in v3_failed))
        if len(pts) >= 2:
            panels.append((wid, wl["name"], "megapixels" if param == "resolution" else param.replace("_", " "),
                           pass_name, expected, sorted(pts), sorted(floor_pts)))
    cols, PW, PH, L, T, GX, GY = 4, 168, 118, 46, 46, 26, 62
    W = cols * (L + PW) + 2 * GX
    rows = (len(panels) + cols - 1) // cols
    H = rows * (T + PH + GY) + 30
    ink, muted, grid, blue = "#0b0b0b", "#52514e", "#e4e3df", "#2a78d6"
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" '
           f'font-family="Helvetica, Arial, sans-serif" font-size="10" fill="{ink}">',
           f'<rect width="{W}" height="{H}" fill="#ffffff"/>']
    for i, (wid, name, xlabel, pass_name, expected, pts, floor_pts) in enumerate(panels):
        ox, oy = (i % cols) * (L + PW) + L, (i // cols) * (T + PH + GY) + T
        logx = wid in LOG_X and min(p[0] for p in pts) > 0
        fx = math.log10 if logx else (lambda x: x)
        xs = [fx(p[0]) for p in pts]
        x0, x1 = min(xs), max(xs)
        pad = (x1 - x0) * 0.08
        x0, x1 = x0 - pad, x1 + pad
        step = nice_step(max(p[3] for p in pts) / 3)
        y1 = step * math.ceil(max(p[3] for p in pts) / step)

        def sx(x):
            return ox + (fx(x) - x0) / (x1 - x0) * PW

        def sy(y):
            return oy + (1.0 - y / y1) * PH
        out.append(f'<text x="{ox}" y="{oy - 28}" font-size="11" font-weight="bold">{wid} {name}</text>')
        out.append(f'<text x="{ox}" y="{oy - 16}" fill="{muted}">{pass_name} pass</text>')
        out.append(f'<text x="{ox}" y="{oy - 4}" fill="{muted}">expected: {expected.split(" (")[0].split(",")[0]}</text>')
        for k in range(int(round(y1 / step)) + 1):
            y = step * k
            out.append(f'<line x1="{ox}" y1="{sy(y):.1f}" x2="{ox + PW}" y2="{sy(y):.1f}" stroke="{grid}"/>')
            out.append(f'<text x="{ox - 4}" y="{sy(y) + 3:.1f}" text-anchor="end" fill="{muted}">{y:g}</text>')
        path = " ".join(f"{sx(p[0]):.1f},{sy(p[1]):.1f}" for p in pts)
        out.append(f'<polyline points="{path}" fill="none" stroke="{blue}" stroke-width="2"/>')
        if floor_pts:  # D-37: the zero-ray floor, one point per resolution or one level for the sweep
            if len(floor_pts) >= 2:
                fpath = " ".join(f"{sx(p[0]):.1f},{sy(p[1]):.1f}" for p in floor_pts)
                out.append(f'<polyline points="{fpath}" fill="none" stroke="{muted}" stroke-width="1.5" '
                           f'stroke-dasharray="4 3"/>')
            else:
                yf = sy(floor_pts[0][1])
                out.append(f'<line x1="{ox}" y1="{yf:.1f}" x2="{ox + PW}" y2="{yf:.1f}" stroke="{muted}" '
                           f'stroke-width="1.5" stroke-dasharray="4 3"/>')
            out.append(f'<text x="{ox + PW}" y="{sy(floor_pts[-1][1]) - 3:.1f}" text-anchor="end" fill="{muted}">'
                       f'no rays</text>')
        last_tick = -1e9
        for x, y, lo, hi, label_text, failed in pts:
            out.append(f'<line x1="{sx(x):.1f}" y1="{sy(lo):.1f}" x2="{sx(x):.1f}" y2="{sy(hi):.1f}" stroke="{blue}"/>')
            fill = "#ffffff" if failed else blue
            out.append(f'<circle cx="{sx(x):.1f}" cy="{sy(y):.1f}" r="4" fill="{fill}" stroke="{blue}" stroke-width="2"/>')
            tick = label_text.replace("x", "×") if xlabel == "megapixels" else label_text
            if sx(x) - last_tick >= 28:  # skip a tick label that would collide with the previous one
                out.append(f'<text x="{sx(x):.1f}" y="{oy + PH + 13}" text-anchor="middle" fill="{muted}">{tick}</text>')
                last_tick = sx(x)
        out.append(f'<text x="{ox + PW / 2}" y="{oy + PH + 27}" text-anchor="middle" fill="{muted}">'
                   f'{xlabel}{" (log scale)" if logx else ""}</text>')
    notes = ["Pass time (ms), median of 5 repeat medians; whiskers: range of repeat medians."]
    if v3_failed:
        notes.append("Hollow points: V3 failed in this bundle, so their timing is withheld.")
    if prov:
        notes.append("Provisional data: see paper/data_sources.json.")
    for j, n in enumerate(notes):
        out.append(f'<text x="{GX}" y="{H - 14 * (len(notes) - j)}" fill="{muted}">{n}</text>')
    out.append("</svg>")
    out_path.write_text("\n".join(out) + "\n", encoding="utf-8")


# fig_frame_structure: the timed pass sequence of one C1 frame. Segment widths are the bundle's C1 pass medians;
# the composite pass is not timed on its own (it sits in the frame-minus-passes residual), so it is drawn hatched
# at a fixed width. Single hue: passes are told apart by their labels, not by colour.
PASS_LABEL = {"gbuffer": "G-buffer", "tlas build": "TLAS", "tlas refit": "TLAS", "shadow rays": "shadow",
              "reflection rays": "reflection", "glass rays": "glass", "diffuse rays": "diffuse"}
PASS_KEY = {"gbuffer": "gbuffer", "tlas": "tlas build", "shadow": "shadow rays", "reflection": "reflection rays",
            "glass": "glass rays", "diffuse": "diffuse rays"}


def fig_frame_structure(bundle, prov, out_path):
    run = load(bundle / "run.json")
    wl = next((w for w in run["workloads"] if w["id"].startswith("C")), None)
    if wl is None:
        return False
    s = load(bundle / wl["runs"][0]["dir"].replace("\\", "/") / "summary.json")
    times = s["across_repeats"]["passes_ms"]
    frame = s["across_repeats"]["gpu_frame_ms_median_of_repeats"]
    segs = []
    for name in wl["passes"]:
        key = PASS_KEY.get(name)
        if key in times:
            segs.append((PASS_LABEL[key], times[key]["median_of_repeats"], True))
        else:
            segs.append((name, None, False))
    W, L, R, Y, BH = 760, 24, 24, 70, 44
    timed_total = sum(t for _, t, ok in segs if ok)
    untimed_w, gap, min_w = 64, 6, 64  # passes shorter than min_w are widened so their labels fit (noted below)
    fixed = sum(1 for *_, ok in segs if not ok) * untimed_w + gap * len(segs)
    scale = (W - L - R - fixed) / timed_total
    for _ in range(5):  # widen short passes, rescale the rest into the remaining width
        small = [t for _, t, ok in segs if ok and t * scale < min_w]
        scale = (W - L - R - fixed - min_w * len(small)) / (timed_total - sum(small))
    widened = [n for n, t, ok in segs if ok and t * scale < min_w]
    ink, muted, blue, light = "#0b0b0b", "#52514e", "#2a78d6", "#cde2fb"
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="270" viewBox="0 0 {W} 270" '
           f'font-family="Helvetica, Arial, sans-serif" font-size="11" fill="{ink}">',
           '<defs><pattern id="hatch" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">'
           f'<line x1="0" y1="0" x2="0" y2="6" stroke="{muted}" stroke-width="1.5"/></pattern></defs>',
           '<rect width="100%" height="100%" fill="#ffffff"/>',
           f'<text x="{L}" y="22" font-weight="bold" font-size="12">One frame of C1, recorded in one command buffer</text>',
           f'<text x="{L}" y="40" fill="{muted}">widths: median pass time (ms) on {load(bundle / "system.json")["device_name"]}; '
           f'frame {frame:.2f} ms</text>']
    x = L
    stamps = []
    for k, (label_text, t, ok) in enumerate(segs):
        w = max(t * scale, min_w) if ok else untimed_w
        fill = blue if ok else "url(#hatch)"
        out.append(f'<rect x="{x:.1f}" y="{Y}" width="{w:.1f}" height="{BH}" rx="3" fill="{fill}"'
                   + ("" if ok else f' stroke="{muted}"') + '/>')
        if ok:
            stamps += [x, x + w]
        cx = x + w / 2
        out.append(f'<text x="{cx:.1f}" y="{Y + BH + 16}" text-anchor="middle">{label_text}</text>')
        out.append(f'<text x="{cx:.1f}" y="{Y + BH + 30}" text-anchor="middle" fill="{muted}">'
                   + (f"{t:.2f}" if ok else "untimed") + '</text>')
        x += w + gap
    for sx_ in stamps:
        out.append(f'<line x1="{sx_:.1f}" y1="{Y - 8}" x2="{sx_:.1f}" y2="{Y}" stroke="{ink}" stroke-width="1.5"/>')
    first_gap = L + max(segs[0][1] * scale, min_w) + gap / 2 if segs[0][2] else None
    out.append(f'<text x="{L}" y="{Y - 14}" fill="{muted}">▾ timestamp: Metal counter sample at the encoder stage '
               f'boundary; Vulkan vkCmdWriteTimestamp2</text>')
    if first_gap:
        out.append(f'<line x1="{first_gap:.1f}" y1="{Y + BH + 40}" x2="{first_gap:.1f}" y2="{Y + BH + 54}" stroke="{muted}"/>')
        out.append(f'<text x="{first_gap - 4:.1f}" y="{Y + BH + 66}" fill="{muted}">gap between passes: Metal fence wait / '
                   f'Vulkan full memory barrier, recorded outside the timestamps, so passes never overlap</text>')
    notes = ["The next frame is recorded only after this one completes (frames serialized).",
             "Hatched: composite, not timed on its own; it sits in the frame-minus-passes residual."]
    if widened:
        notes.append(f"{' and '.join(widened)} drawn wider than to scale so the labels fit.")
    for j, n in enumerate(notes):
        out.append(f'<text x="{L}" y="{Y + BH + 92 + 15 * j}" fill="{muted}">{n}</text>')
    if prov:
        out.append(f'<text x="{W - R}" y="262" text-anchor="end" font-size="10" fill="{muted}">provisional data: '
                   f'see paper/data_sources.json</text>')
    out.append("</svg>")
    out_path.write_text("\n".join(out) + "\n", encoding="utf-8")
    return True


# fig_variation: V4 as a dot plot, one row per run in suite order: the CoV of the clean repeats (D-35) on a log axis
# (values span three decades), with the two bands as dashed lines. One series, so no legend; marker shape tells the
# run kinds apart (the first workload opens the session, C1 is the composite) and the notes say so. A run outside its
# band, or with too few clean repeats, is labelled; flagged repeats are counted beside the marker. V5 adds a second
# machine later.
def fig_variation(bundle, prov, out_path):
    rows = []
    for wl, r, s in runs(bundle):
        x = d35.run_verdict(bundle, r)
        rows.append((wl["id"], label(wl["id"], r["value"]), x["gpu_frame_ms_cov_clean"] * 100.0, x["v4_band"] * 100.0,
                     len(x["flagged_repeats"]), x))
    first_id = rows[0][0]
    preheated = load(bundle / next(runs(bundle))[1]["dir"].replace("\\", "/") / "summary.json").get("preheat_s", 0) > 0
    W, L, R, T, RH = 640, 110, 30, 58, 14
    H = T + RH * len(rows) + 106
    positive = [c for _, _, c, *_ in rows if c > 0]
    lo = 10.0 ** math.floor(math.log10(min(positive)))
    hi = 10.0 ** math.ceil(math.log10(max(positive + [d35.BAND_LIGHT * 100.0])))

    def sx(c):
        c = max(c, lo)  # a single clean repeat has no spread; drawn at the axis start
        return L + (math.log10(c) - math.log10(lo)) / (math.log10(hi) - math.log10(lo)) * (W - L - R)
    ink, muted, grid, blue = "#0b0b0b", "#52514e", "#e4e3df", "#2a78d6"
    bottom = T + RH * len(rows)
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" '
           f'font-family="Helvetica, Arial, sans-serif" font-size="10" fill="{ink}">',
           f'<rect width="{W}" height="{H}" fill="#ffffff"/>',
           f'<text x="{L}" y="20" font-size="12" font-weight="bold">V4 repeatability on '
           f'{load(bundle / "system.json")["device_name"]}</text>',
           f'<text x="{L}" y="36" fill="{muted}">coefficient of variation of the GPU frame median over the clean '
           f'repeats (D-35), 5 repeats per run</text>']
    k = 0
    while lo * 10 ** k <= hi * 1.0001:
        c = lo * 10 ** k
        out.append(f'<line x1="{sx(c):.1f}" y1="{T - 4}" x2="{sx(c):.1f}" y2="{bottom}" stroke="{grid}"/>')
        out.append(f'<text x="{sx(c):.1f}" y="{bottom + 14}" text-anchor="middle" fill="{muted}">{c:g} %</text>')
        k += 1
    out.append(f'<text x="{(L + W - R) / 2}" y="{bottom + 30}" text-anchor="middle" fill="{muted}">'
               f'coefficient of variation (log scale)</text>')
    # The two band lines sit close together, so the 0.5 % label goes left of its line and the 2 % label right.
    for band, text, dx, anchor in ((d35.BAND_HEAVY * 100.0, "0.5 %: frames ≥ 1 ms", -4, "end"),
                                   (d35.BAND_LIGHT * 100.0, "2 %: frames &lt; 1 ms", 4, "start")):
        out.append(f'<line x1="{sx(band):.1f}" y1="{T - 10}" x2="{sx(band):.1f}" y2="{bottom}" stroke="{muted}" '
                   f'stroke-dasharray="4 3"/>')
        out.append(f'<text x="{sx(band) + dx:.1f}" y="{T - 2}" text-anchor="{anchor}" fill="{muted}">{text}</text>')
    for i, (wid, name, c, band, nflag, x) in enumerate(rows):
        y = T + RH * i + RH / 2
        out.append(f'<text x="{L - 8}" y="{y + 3.5:.1f}" text-anchor="end" fill="{muted}">{name}</text>')
        out.append(f'<line x1="{L}" y1="{y:.1f}" x2="{W - R}" y2="{y:.1f}" stroke="{grid}" stroke-width="0.5"/>')  # row guide; no stem on a log axis
        if wid.startswith("C"):
            out.append(f'<rect x="{sx(c) - 4:.1f}" y="{y - 4:.1f}" width="8" height="8" fill="{blue}" '
                       f'transform="rotate(45 {sx(c):.1f} {y:.1f})"/>')
        else:
            fill = "#ffffff" if wid == first_id else blue
            out.append(f'<circle cx="{sx(c):.1f}" cy="{y:.1f}" r="4" fill="{fill}" stroke="{blue}" stroke-width="2"/>')
        tags = []
        if x["unstable"]:
            tags.append(f"{x['clean_repeats']} clean")
        elif c >= band:
            tags.append(f"{c:.2f} %")
        if nflag:
            tags.append(f"{nflag} flagged")
        if x["remeasured"]:
            tags.append("re-measured")
        if tags:
            out.append(f'<text x="{sx(c) + 8:.1f}" y="{y + 3.5:.1f}">{", ".join(tags)}</text>')
    notes = [f"Hollow: {first_id}, the first workload, measured "
             + ("right after the 30-s pre-heat." if preheated else "before the pre-heat existed."),
             "Diamond: C1 composite. Filled: isolated workloads. Labelled: runs outside their band (value), runs",
             "with fewer than 3 clean repeats (count), and repeats flagged as slow (more than 5 % above the fastest)."]
    if prov:
        notes.append("Provisional data: see paper/data_sources.json.")
    for j, n in enumerate(notes):
        out.append(f'<text x="{L}" y="{bottom + 50 + 14 * j}" fill="{muted}">{n}</text>')
    out.append("</svg>")
    out_path.write_text("\n".join(out) + "\n", encoding="utf-8")


# fig_graphical_abstract: the method as one horizontal strip, 1328 x 531 px (the template's minimum), read at
# 13 x 5 cm, so no text below 26 px. The frame strip uses the C1 pass medians and the curve the first sustained run;
# everything else is schematic. Redrawn from M7 bundles once the Vulkan side has data.
def c1_pass_medians(bundle):
    run = load(bundle / "run.json")
    wl = next((w for w in run["workloads"] if w["id"].startswith("C")), None)
    if wl is None:
        return None
    times = load(bundle / wl["runs"][0]["dir"].replace("\\", "/") / "summary.json")["across_repeats"]["passes_ms"]
    return [times[PASS_KEY[n]]["median_of_repeats"] for n in wl["passes"] if PASS_KEY.get(n) in times]


def fig_graphical_abstract(bundle, sustained_bundle, prov, out_path, others=()):
    """others: (short name, suite bundle) of further devices; their C1 passes stand beside the reference's."""
    passes = c1_pass_medians(bundle)
    if passes is None or sustained_bundle is None:
        return False
    frames = [("M5" if others else "", passes)] + [(n, c1_pass_medians(b)) for n, b in others]
    frames = [(n, ps) for n, ps in frames if ps]
    rows = sus.load_timeline(sustained_bundle)
    _, ref = sus.reference(rows)
    curve = binned([(t, g / ref[k]) for t, k, g in rows if k in ref], bin_s=30.0)
    W, H, top, bh = 1328, 531, 150, 250
    ink, muted, blue, light = "#0b0b0b", "#52514e", "#2a78d6", "#cde2fb"
    cols = [(24, 220), (300, 300), (656, 216), (928, 140), (1124, 180)]  # (x, width) of the five stages
    titles = ["one source", "timed passes", "gates", "bundle", "burst → steady"]
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" '
           f'font-family="Helvetica, Arial, sans-serif" font-size="28" fill="{ink}">',
           f'<rect width="{W}" height="{H}" fill="#ffffff"/>',
           f'<text x="24" y="64" font-size="36" font-weight="bold">Same rays, same image, then compare the time</text>']
    for (x, w), t in zip(cols, titles):
        out.append(f'<text x="{x + w / 2}" y="{top - 16}" text-anchor="middle" font-weight="bold">{t}</text>')
    for (x0, w0), (x1, _) in zip(cols, cols[1:]):  # arrows between stages
        a, b, y = x0 + w0 + 8, x1 - 8, top + bh / 2
        out.append(f'<line x1="{a}" y1="{y}" x2="{b - 10}" y2="{y}" stroke="{muted}" stroke-width="3"/>')
        out.append(f'<path d="M{b - 14},{y - 9} L{b},{y} L{b - 14},{y + 9} Z" fill="{muted}"/>')
    # 1: one Slang source forking to Metal and Vulkan
    x, w = cols[0]
    out.append(f'<rect x="{x}" y="{top + 10}" width="{w}" height="70" rx="8" fill="{light}"/>')
    out.append(f'<text x="{x + w / 2}" y="{top + 55}" text-anchor="middle">Slang kernels</text>')
    bx = x + 14  # a bracket from the source to both backends, so neither box looks downstream of the other
    out.append(f'<line x1="{bx}" y1="{top + 80}" x2="{bx}" y2="{top + 214}" stroke="{muted}" stroke-width="2"/>')
    for j, api in enumerate(("Metal", "Vulkan")):
        yy = top + 144 + 70 * j
        out.append(f'<line x1="{bx}" y1="{yy}" x2="{x + 40}" y2="{yy}" stroke="{muted}" stroke-width="2"/>')
        out.append(f'<rect x="{x + 40}" y="{yy - 22}" width="{w - 40}" height="44" rx="8" fill="#ffffff" stroke="{blue}" '
                   f'stroke-width="2"/>')
        out.append(f'<text x="{x + 20 + w / 2}" y="{yy + 10}" text-anchor="middle">{api}</text>')
    # 2: the frame as stacked timed passes (heights from the pass medians, each device scaled to its own frame),
    # ray queries only
    x, w = cols[1]
    labelled = len(frames) > 1
    bw = (w - 80) / len(frames)
    for j, (name, ps) in enumerate(frames):
        total, y = sum(ps), top + (40 if labelled else 10)
        bx = x + 40 + j * bw + (6 if labelled else 0)
        if labelled:
            out.append(f'<text x="{bx + bw / 2 - 6:.1f}" y="{top + 28}" text-anchor="middle" font-size="22" '
                       f'fill="{muted}">{name}</text>')
        for t in ps:
            h = max(t / total * (bh - 70 - (30 if labelled else 0)), 8)
            out.append(f'<rect x="{bx:.1f}" y="{y:.1f}" width="{bw - (12 if labelled else 0):.1f}" height="{h - 4:.1f}" '
                       f'rx="3" fill="{blue}"/>')
            y += h
    out.append(f'<text x="{x + w / 2}" y="{top + bh + 4}" text-anchor="middle" fill="{muted}">one pass per effect,</text>')
    out.append(f'<text x="{x + w / 2}" y="{top + bh + 38}" text-anchor="middle" fill="{muted}">inline ray queries</text>')
    # 3: the three gates
    x, w = cols[2]
    for j, g in enumerate(("V1 image", "V2 ray count", "V3 depth")):
        yy = top + 40 + 70 * j
        out.append(f'<path d="M{x + 6},{yy - 8} l10,12 l20,-26" fill="none" stroke="{blue}" stroke-width="5" '
                   f'stroke-linecap="round" stroke-linejoin="round"/>')
        out.append(f'<text x="{x + 48}" y="{yy + 2}">{g}</text>')
    out.append(f'<text x="{x + w / 2}" y="{top + bh + 4}" text-anchor="middle" fill="{muted}">fail: timing</text>')
    out.append(f'<text x="{x + w / 2}" y="{top + bh + 38}" text-anchor="middle" fill="{muted}">withheld</text>')
    # 4: the self-describing bundle
    x, w = cols[3]
    out.append(f'<path d="M{x + 20},{top + 40} h40 l12,14 h48 v150 h-100 Z" fill="{light}" stroke="{blue}" stroke-width="2"/>')
    for j, f in enumerate(("json", "png", "csv")):
        out.append(f'<text x="{x + 70}" y="{top + 100 + 40 * j}" text-anchor="middle" font-size="26">{f}</text>')
    out.append(f'<text x="{x + w / 2}" y="{top + bh + 4}" text-anchor="middle" fill="{muted}">no engine</text>')
    out.append(f'<text x="{x + w / 2}" y="{top + bh + 38}" text-anchor="middle" fill="{muted}">to analyse</text>')
    # 5: the sustained curve (frame time relative to burst), axes without numbers
    x, w = cols[4]
    tmax = curve[-1][0]
    ys = [r for _, r in curve]
    lo, hi = min(ys) - 0.01, max(ys) + 0.01
    path = " ".join(f"{x + 10 + t / tmax * (w - 20):.1f},{top + 190 - (r - lo) / (hi - lo) * 160:.1f}" for t, r in curve)
    out.append(f'<line x1="{x + 10}" y1="{top + 200}" x2="{x + w - 10}" y2="{top + 200}" stroke="{muted}" stroke-width="2"/>')
    out.append(f'<line x1="{x + 10}" y1="{top + 20}" x2="{x + 10}" y2="{top + 200}" stroke="{muted}" stroke-width="2"/>')
    out.append(f'<polyline points="{path}" fill="none" stroke="{blue}" stroke-width="4"/>')
    out.append(f'<text x="{x + w / 2}" y="{top + bh + 4}" text-anchor="middle" fill="{muted}">frame time,</text>')
    out.append(f'<text x="{x + w / 2}" y="{top + bh + 38}" text-anchor="middle" fill="{muted}">fanless laptop</text>')
    if prov:
        out.append(f'<text x="{W - 24}" y="{H - 16}" text-anchor="end" font-size="26" fill="{muted}">provisional data</text>')
    out.append("</svg>")
    out_path.write_text("\n".join(out) + "\n", encoding="utf-8")
    return True


def main() -> int:
    args = sys.argv[1:]
    sources_path = Path(args[args.index("--sources") + 1]) if "--sources" in args else ROOT / "paper" / "data_sources.json"
    out = Path(args[args.index("--out") + 1]) if "--out" in args else ROOT / "paper" / "generated"
    sources = load(sources_path)
    provisional = set(sources.get("provisional", []))
    v, tables = Values(), []
    sustained_runs, suites = [], []
    for role, rel in sources["bundles"].items():
        if not rel:
            continue
        bundle = (ROOT / rel).resolve()
        kind, tag = role.split(":", 1)
        prov = rel in provisional
        if kind == "suite":
            suite_values(v, bundle, prov, tag, tables)
            scaling_values(v, bundle, prov, tag, tables)
            suites.append((tag, bundle, prov))
        elif kind == "sustained":
            sustained_values(v, bundle, prov, tag, tables)
            d = v.items[f"v9_{tag}"]["data"]
            sustained_runs.append((tag.split("_", 1)[-1], bundle, prov, d["time_to_steady_s"],
                                   d.get("power", {}).get("time_to_steady_s")))
        else:
            raise SystemExit(f"unknown role kind {kind!r} in {sources_path}")

    # c1_track, v9_burst_spread and fig_sustained compare runs on one device only: each suite with its own device's
    # sustained runs, the spread and the figure on the first suite's device (the M5 since M7)
    for tag, bundle, prov in suites:
        same = [r for r in sustained_runs if device_of(r[1]) == device_of(bundle)]
        if same and (bundle / "workloads" / "C1_fixed" / "frames.csv").exists():
            c1_track_values(v, bundle, {b: n for n, b, *_ in same}, prov or any(p for _, _, p, *_ in same), tag)
    ref_runs = [r for r in sustained_runs if not suites or device_of(r[1]) == device_of(suites[0][1])]
    others = [(tag, bundle, prov) for tag, bundle, prov in suites[1:] if device_of(bundle) != device_of(suites[0][1])]
    out.mkdir(parents=True, exist_ok=True)
    for tag, bundle, prov in others:
        report = parity_values(v, suites[0][1], bundle, prov or suites[0][2], tag)
        fig_parity(suites[0][1], bundle, report, prov or suites[0][2], out / f"fig_parity_{tag}.svg")
        v.put(f"fig_parity_{tag}", f"![fig_parity_{tag}](fig_parity_{tag}.svg)", f"{suites[0][1].name}, {bundle.name}",
              prov or suites[0][2])
    if others:
        names = {t: device_of(b).replace("NVIDIA GeForce ", "") for t, b, _ in suites}
        mrays_devices(v, tables, suites[0][0], [t for t, *_ in others], names,
                      ", ".join(b.name for _, b, _ in [suites[0]] + others), any(p for *_, p in [suites[0]] + others))
    if suites:
        t = ["tab_devices", "| Device | Session (UTC) | API | OS | Shader compiler / driver | Shader source | Memory | "
             "GPU timer | Power | Build (engine commit, shader fingerprint) |", "|---|---|---|---|---|---|---|---|---|---|"] \
            + [device_row(b) for _, b, _ in suites]
        add_table(v, tables, t, ", ".join(b.name for _, b, _ in suites), any(p for *_, p in suites))
    out.mkdir(parents=True, exist_ok=True)
    for tag, bundle, prov in suites:
        fig_scaling(bundle, prov, out / f"fig_scaling_{tag}.svg")
        v.put(f"fig_scaling_{tag}", f"![fig_scaling_{tag}](fig_scaling_{tag}.svg)", bundle.name, prov)
        fig_variation(bundle, prov, out / f"fig_variation_{tag}.svg")
        v.put(f"fig_variation_{tag}", f"![fig_variation_{tag}](fig_variation_{tag}.svg)", bundle.name, prov)
    if suites:
        tag, bundle, prov = suites[0]
        if fig_frame_structure(bundle, prov, out / "fig_frame_structure.svg"):
            v.put("fig_frame_structure", "![fig_frame_structure](fig_frame_structure.svg)", bundle.name, prov)
        fanless = next(((b, p) for n, b, p, *_ in sustained_runs if n == "fanless"), (None, False))
        short = [(device_of(b).replace("NVIDIA GeForce RTX ", "").replace("NVIDIA GeForce ", ""), b)
                 for _, b, _ in suites[1:] if device_of(b) != device_of(bundle)]
        if fig_graphical_abstract(bundle, fanless[0], prov or fanless[1], out / "fig_graphical_abstract.svg", short):
            v.put("fig_graphical_abstract", "![fig_graphical_abstract](fig_graphical_abstract.svg)", bundle.name,
                  prov or fanless[1])
    ref_tags = {"v9_" + role.split(":", 1)[1] for role, rel in sources["bundles"].items()
                if rel and role.startswith("sustained:") and (ROOT / rel).resolve() in {b for _, b, *_ in ref_runs}}
    bursts = [(k[3:], it["data"]["burst_gpu_frame_ms_median"]) for k, it in v.items.items()
              if k in ref_tags and isinstance(it.get("data"), dict) and "burst_gpu_frame_ms_median" in it["data"]]
    if len(bursts) >= 2:
        lo, hi = min(b for _, b in bursts), max(b for _, b in bursts)
        v.put("v9_burst_spread", f"{(hi / lo - 1.0) * 100:.2f} %", ", ".join(b.name for _, b, *_ in ref_runs),
              any(p for _, _, p, *_ in ref_runs), bursts)
    # repeats of a sustained condition (D-31 spread): their own ranges value, faded lines in fig_sustained; they never
    # enter v9_burst_spread or c1_track, which compare the reference runs
    repeats = {}
    for role, rels in sources.get("repeats", {}).items():
        ref = sources["bundles"].get(role)
        if not ref or not rels:
            continue
        reps = [(ROOT / r).resolve() for r in rels]
        repeat_spread_values(v, role.split(":", 1)[1], (ROOT / ref).resolve(), reps,
                             ref in provisional or any(r in provisional for r in rels))
        repeats[(ROOT / ref).resolve()] = reps
    if ref_runs:
        fig_sustained(ref_runs, out / "fig_sustained.svg", repeats.get(ref_runs[0][1], []))
        v.put("fig_sustained", "![fig_sustained](fig_sustained.svg)",
              ", ".join([b.name for _, b, *_ in ref_runs] + [b.name for r in repeats.values() for b in r]),
              any(p for _, _, p, *_ in ref_runs))
    (out / "values.json").write_text(json.dumps(v.items, indent=1, ensure_ascii=False), encoding="utf-8")
    (out / "tables.md").write_text("# Generated tables (tools/analyze/paper_data.py)\n\nDo not edit; re-run the script.\n\n"
                                   + "\n\n".join(tables) + "\n", encoding="utf-8")

    draft = (ROOT / "paper" / "manuscript.md").read_text(encoding="utf-8")
    filled, missing = [], set()

    def sub(m):
        item = v.items.get(m.group(1))
        if item is None:
            missing.add(m.group(1))
            return m.group(0)
        filled.append(m.group(1))
        text, caption = item["text"], (m.group(2) or "").strip()
        if text.startswith("!["):                    # figure: the caption becomes the image's alt text
            text = re.sub(r"^!\[[^\]]*\]", "![" + caption + "]", text)
        elif text.startswith("|") and caption:       # table: a "Table: ..." line that build_docx.py turns into a caption
            text = f"Table: {caption}\n\n{text}"
        if not item["provisional"]:
            return text
        return text + ("\n\n(provisional)" if "\n" in text else " (provisional)")

    (out / "manuscript.filled.md").write_text(PLACEHOLDER.sub(sub, draft), encoding="utf-8")
    print(f"{len(v.items)} values, {len(tables)} tables -> {out}")
    print(f"filled {len(filled)} placeholders; still open: {', '.join(sorted(missing)) or 'none'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
