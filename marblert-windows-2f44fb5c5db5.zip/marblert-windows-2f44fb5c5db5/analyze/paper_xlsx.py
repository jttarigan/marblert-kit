#!/usr/bin/env python3
"""Excel workbooks for the paper's data charts (LAB.md, Paper finishing: every chart that shows data also ships as a
workbook with the data and a native Excel chart, so the user can remake it).

Usage: paper_xlsx.py [--sources paper/data_sources.json] [--out paper/generated/xlsx]

Reads the same bundles as paper_data.py and takes the plotted values the same way (same helpers, same bins), one
workbook per figure the draft uses: fig_sustained, fig_scaling_<tag>, fig_variation_<tag>, fig_frame_structure.
fig_parity_<tag> (an image) and fig_graphical_abstract (schematic) have no chart data and get none.
Needs openpyxl (not part of the engine build).
"""
import statistics
import sys
from pathlib import Path

from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference, ScatterChart, Series
from openpyxl.chart.error_bar import ErrorBars
from openpyxl.chart.series import SeriesLabel
from openpyxl.chart.data_source import NumDataSource, NumRef

sys.path.insert(0, str(Path(__file__).resolve().parent))
import paper_data as pd  # noqa: E402  (data helpers and figure constants shared with the SVG figures)
import repeat_spread as d35  # noqa: E402
import scaling  # noqa: E402
import sustained as sus  # noqa: E402


def about(wb, figure, caption, sources):
    ws = wb.create_sheet("about", 0)
    for row in (("figure", figure), ("caption", caption), ("source bundles", ", ".join(sources)),
                ("made by", "tools/analyze/paper_xlsx.py; do not edit, re-run the script")):
        ws.append(row)
    ws.column_dimensions["A"].width = 16
    ws.column_dimensions["B"].width = 110


def line_series(ws, xcol, ycol, first, last, title):
    s = Series(Reference(ws, min_col=ycol, min_row=first, max_row=last),
               Reference(ws, min_col=xcol, min_row=first, max_row=last))
    s.tx = SeriesLabel(v=title)
    s.marker.symbol = "none"
    s.smooth = False
    return s


def sustained_workbook(entries, repeats, out_path):
    """Panel a: GPU frame time / burst median per 10-s bin; panel b: SoC power (mean per bin). Same as fig_sustained."""
    cols = []  # (title, panel, binned points)
    for name, bundle, _prov, _t, _pt in entries:
        rows = sus.load_timeline(bundle)
        _, ref = sus.reference(rows)
        cols.append((f"{name} ({bundle.name})", "a", pd.binned([(t, g / ref[k]) for t, k, g in rows if k in ref])))
        end = rows[-1][0]
        prow = sus.load_power(bundle)
        if prow:
            cols.append((f"{name} ({bundle.name})", "b",
                         pd.binned([(t, c / 1000.0) for t, c, _ in prow if t <= end], agg=statistics.fmean)))
    for bundle in repeats:
        rows = sus.load_timeline(bundle)
        _, ref = sus.reference(rows)
        cols.append((f"{entries[0][0]} repeat ({bundle.name})", "a",
                     pd.binned([(t, g / ref[k]) for t, k, g in rows if k in ref])))
    wb = Workbook()
    wb.remove(wb.active)
    for panel, sheet, ytitle in (("a", "a_frame_ratio", "ratio to burst"), ("b", "b_soc_power", "power (W)")):
        mine = [c for c in cols if c[1] == panel]
        if not mine:
            continue
        ws = wb.create_sheet(sheet)
        times = sorted({t for *_, pts in mine for t, _ in pts})
        ws.append(["time (min), bin centre"] + [c[0] for c in mine])
        lookup = [dict(pts) for *_, pts in mine]
        for t in times:
            ws.append([t / 60.0] + [d.get(t) for d in lookup])
        ch = ScatterChart()
        ch.title = ("a  GPU frame time relative to the burst period" if panel == "a"
                    else "b  SoC power (CPU + GPU, powermetrics)")
        ch.style, ch.height, ch.width = 13, 9, 18
        ch.x_axis.title, ch.y_axis.title = f"time since start (min); {pd.BIN_S:.0f}-s bins", ytitle
        for j, c in enumerate(mine):
            ch.series.append(line_series(ws, 1, 2 + j, 2, len(times) + 1, c[0]))
        ws.add_chart(ch, f"{chr(ord('B') + len(mine) + 1)}2")
    st = wb.create_sheet("steady_state")
    st.append(["run", "bundle", "steady from (s), frame time", "steady from (s), power"])
    for name, bundle, _prov, t, pt in entries:
        st.append([name, bundle.name, t, pt])
    about(wb, "fig_sustained", "Sustained C1 runs on the Apple M5 (see the caption in paper/manuscript.md).",
          [b.name for _, b, *_ in entries] + [b.name for b in repeats])
    wb.save(out_path)


def scaling_workbook(bundle, out_path):
    """One sheet and chart per swept workload: the median of the repeat medians of its stressed pass, whiskers the
    range of the repeat medians, V3 failures marked, the D-37 zero-ray floor beside. Same as fig_scaling."""
    run = pd.load(bundle / "run.json")
    v3_failed = {(c["workload"], c["value"]) for c in (pd.load(bundle / "checks.json").get("v3", [])
                                                        if (bundle / "checks.json").exists() else []) if not c["pass"]}
    wb = Workbook()
    wb.remove(wb.active)
    for wl in run.get("workloads", []):
        wid = wl["id"]
        if wid not in scaling.EXPECTED:
            continue
        param, pass_name, expected = scaling.EXPECTED[wid]
        pts, floor_pts = [], []
        for r in wl.get("runs", []):
            s = pd.load(bundle / r["dir"].replace("\\", "/") / "summary.json")
            p = s["across_repeats"].get("passes_ms", {}).get(pass_name)
            if p is None:
                continue
            if s["value"].startswith("floor"):
                xf = scaling.numeric(s.get("floor_of", "")) / (1.0e6 if param == "resolution" else 1.0)
                floor_pts.append((xf, p["median_of_repeats"]))
                continue
            meds = [rep["passes_ms"][pass_name]["median"] for rep in s["repeats"]
                    if rep.get("timed") and pass_name in rep.get("passes_ms", {})]
            x = scaling.numeric(s["value"]) / (1.0e6 if param == "resolution" else 1.0)
            pts.append((x, p["median_of_repeats"], min(meds or [0]), max(meds or [0]), s["value"],
                        (wid, s["value"]) in v3_failed))
        if len(pts) < 2:
            continue
        pts.sort()
        floor_pts.sort()
        xlabel = "megapixels" if param == "resolution" else param.replace("_", " ")
        ws = wb.create_sheet(wid)
        ws.append([xlabel, f"{pass_name} pass (ms), median of repeat medians", "min of repeat medians",
                   "max of repeat medians", "value", "V3 failed (timing withheld)", "minus", "plus"])
        for x, y, lo, hi, value, failed in pts:
            ws.append([x, y, lo, hi, value, "yes" if failed else "", y - lo, hi - y])
        n = len(pts)
        ch = ScatterChart()
        ch.title = f"{wid} {wl['name']}: {pass_name} pass (expected: {expected.split(' (')[0].split(',')[0]})"
        ch.style, ch.height, ch.width = 13, 8, 14
        ch.x_axis.title, ch.y_axis.title = xlabel + (" (log scale)" if wid in pd.LOG_X else ""), "pass time (ms)"
        if wid in pd.LOG_X and min(p[0] for p in pts) > 0:
            ch.x_axis.scaling.logBase = 10
        s = line_series(ws, 1, 2, 2, n + 1, f"{pass_name} pass")
        s.marker.symbol = "circle"
        s.errBars = ErrorBars(errDir="y", errBarType="both", errValType="cust", noEndCap=True,
                              minus=NumDataSource(numRef=NumRef(f="'{0}'!$G$2:$G${1}".format(wid, n + 1))),
                              plus=NumDataSource(numRef=NumRef(f="'{0}'!$H$2:$H${1}".format(wid, n + 1))))
        ch.series.append(s)
        if floor_pts:
            r0 = n + 3
            ws.cell(row=r0, column=1, value=f"{xlabel} (zero-ray floor, D-37)")
            ws.cell(row=r0, column=2, value=f"{pass_name} pass (ms), no rays")
            fl = floor_pts if len(floor_pts) >= 2 else [(pts[0][0], floor_pts[0][1]), (pts[-1][0], floor_pts[0][1])]
            for k, (x, y) in enumerate(fl):
                ws.cell(row=r0 + 1 + k, column=1, value=x)
                ws.cell(row=r0 + 1 + k, column=2, value=y)
            f = line_series(ws, 1, 2, r0 + 1, r0 + len(fl), "no rays")
            f.graphicalProperties.line.dashStyle = "dash"
            ch.series.append(f)
        ws.add_chart(ch, "J2")
        for c in "ABCDEFGH":
            ws.column_dimensions[c].width = 16
    about(wb, out_path.stem, "V6 sweep scaling (see the caption in paper/manuscript.md). Columns minus/plus give the "
          "whiskers (range of the repeat medians) as Excel custom error bars.", [bundle.name])
    wb.save(out_path)


def variation_workbook(bundle, out_path):
    """V4: CoV of the GPU frame median over the clean repeats per run, with its band. Same as fig_variation."""
    wb = Workbook()
    ws = wb.active
    ws.title = "v4"
    ws.append(["run", "CoV of clean repeats (%)", "band (%)", "kind", "clean repeats", "flagged repeats",
               "re-measured", "V4 pass"])
    rows = list(pd.runs(bundle))
    first_id = rows[0][0]["id"]
    for wl, r, _s in rows:
        x = d35.run_verdict(bundle, r)
        kind = "composite" if wl["id"].startswith("C") else ("first workload" if wl["id"] == first_id else "isolated")
        ws.append([pd.label(wl["id"], r["value"]), x["gpu_frame_ms_cov_clean"] * 100.0, x["v4_band"] * 100.0, kind,
                   x["clean_repeats"], len(x["flagged_repeats"]), "yes" if x["remeasured"] else "",
                   "yes" if x["v4_pass"] else "no"])
    n = len(rows)
    ch = BarChart()
    ch.type, ch.style, ch.height, ch.width = "bar", 10, 4 + 0.45 * n, 16
    ch.title = f"V4 repeatability on {pd.device_of(bundle)}"
    ch.y_axis.title = "coefficient of variation (%, log scale)"
    ch.y_axis.scaling.logBase = 10
    ch.x_axis.scaling.orientation = "maxMin"  # suite order from the top, as in the SVG
    ch.add_data(Reference(ws, min_col=2, max_col=3, min_row=1, max_row=n + 1), titles_from_data=True)
    ch.set_categories(Reference(ws, min_col=1, min_row=2, max_row=n + 1))
    ws.add_chart(ch, "J2")
    ws.column_dimensions["A"].width = 18
    for c in "BCDEFGH":
        ws.column_dimensions[c].width = 14
    about(wb, out_path.stem, "V4 repeatability (see the caption in paper/manuscript.md). Bands: 2 % for frames under "
          "1 ms, 0.5 % otherwise (D-35).", [bundle.name])
    wb.save(out_path)


def frame_structure_workbook(bundle, out_path):
    """Median pass times of one C1 frame, in recording order. Same numbers as fig_frame_structure."""
    run = pd.load(bundle / "run.json")
    wl = next((w for w in run["workloads"] if w["id"].startswith("C")), None)
    if wl is None:
        return False
    s = pd.load(bundle / wl["runs"][0]["dir"].replace("\\", "/") / "summary.json")
    times = s["across_repeats"]["passes_ms"]
    wb = Workbook()
    ws = wb.active
    ws.title = "c1_passes"
    ws.append(["pass", "median pass time (ms)", "timed"])
    for name in wl["passes"]:
        key = pd.PASS_KEY.get(name)
        if key in times:
            ws.append([pd.PASS_LABEL[key], times[key]["median_of_repeats"], "yes"])
        else:
            ws.append([name, None, "no (in the frame-minus-passes residual)"])
    n = len(wl["passes"])
    ws.append([])
    ws.append(["GPU frame (ms), median of repeats", s["across_repeats"]["gpu_frame_ms_median_of_repeats"]])
    ch = BarChart()
    ch.type, ch.style, ch.height, ch.width = "bar", 10, 7, 16
    ch.title = f"One frame of C1 on {pd.device_of(bundle)}: median pass time (ms)"
    ch.x_axis.scaling.orientation = "maxMin"
    ch.add_data(Reference(ws, min_col=2, min_row=1, max_row=n + 1), titles_from_data=True)
    ch.set_categories(Reference(ws, min_col=1, min_row=2, max_row=n + 1))
    ch.legend = None
    ws.add_chart(ch, "E2")
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 22
    ws.column_dimensions["C"].width = 36
    about(wb, "fig_frame_structure", "One frame of C1 (see the caption in paper/manuscript.md). The SVG widens the "
          "G-buffer and TLAS bars so their labels fit; these are the true values.", [bundle.name])
    wb.save(out_path)
    return True


def main() -> int:
    args = sys.argv[1:]
    sources_path = Path(args[args.index("--sources") + 1]) if "--sources" in args else pd.ROOT / "paper" / "data_sources.json"
    out = Path(args[args.index("--out") + 1]) if "--out" in args else pd.ROOT / "paper" / "generated" / "xlsx"
    sources = pd.load(sources_path)
    draft = (pd.ROOT / "paper" / "manuscript.md").read_text(encoding="utf-8")
    used = {key for key, _caption in pd.PLACEHOLDER.findall(draft)}
    out.mkdir(parents=True, exist_ok=True)
    suites, sustained_runs = [], []
    for role, rel in sources["bundles"].items():
        if not rel:
            continue
        kind, tag = role.split(":", 1)
        bundle = (pd.ROOT / rel).resolve()
        if kind == "suite":
            suites.append((tag, bundle))
        elif kind == "sustained":
            sustained_runs.append((tag, bundle))
    written = []
    for tag, bundle in suites:
        for key, make in ((f"fig_scaling_{tag}", scaling_workbook), (f"fig_variation_{tag}", variation_workbook)):
            if key in used:
                make(bundle, out / f"{key}.xlsx")
                written.append(key)
    if suites and "fig_frame_structure" in used and frame_structure_workbook(suites[0][1], out / "fig_frame_structure.xlsx"):
        written.append("fig_frame_structure")
    if "fig_sustained" in used and suites:
        # the same entries as paper_data.py: the first suite's device, steady-state starts from the D-31 rule
        ref_dev = pd.device_of(suites[0][1])
        entries = []
        for tag, bundle in sustained_runs:
            if pd.device_of(bundle) != ref_dev:
                continue
            d = pd.sustained_json(bundle)
            entries.append((tag.split("_", 1)[-1], bundle, False, d["time_to_steady_s"],
                            d.get("power", {}).get("time_to_steady_s")))
        reps = [(pd.ROOT / r).resolve() for r in sources.get("repeats", {}).get(f"sustained:{sustained_runs[0][0]}", [])]
        sustained_workbook(entries, reps, out / "fig_sustained.xlsx")
        written.append("fig_sustained")
    for key in sorted(k for k in used if k.startswith("fig_") and k not in written):
        print(f"{key}: no chart data, no workbook")
    print("wrote", ", ".join(f"{k}.xlsx" for k in written), "to", out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
