#!/usr/bin/env python3
"""Validation V6: do sweeps scale as expected? Reads one bundle and, per workload, fits the
measured pass time against the swept parameter (or pixel count for resolution sweeps).

Usage: scaling.py <bundle dir> [--json out.json]
Reports the slope of a least-squares line through (parameter, median pass time), the
correlation coefficient, and the ratio last/first against the parameter ratio. The expected
shape per workload is stated so the reader can judge it; nothing here replaces the pilot data.
Standard library only.
"""
import json
import math
import sys
from pathlib import Path

EXPECTED = {
    "W0": ("resolution", "gbuffer", "linear in pixels"),
    "W1": ("resolution", "primary rays", "linear in pixels"),
    "W2": ("resolution", "shadow rays", "linear in pixels"),
    "W3": ("lights", "shadow rays", "linear in lights"),
    "W4": ("coverage", "reflection rays", "linear in coverage"),
    "W5": ("roughness", "reflection rays", "rising with roughness (incoherence)"),
    "W6": ("bounces", "glass rays", "sub-linear in bounce limit (paths terminate)"),
    "W7": ("alpha_coverage", "shadow rays", "rising with alpha-tested fraction (candidate loop)"),
    "W8": ("instances", "tlas build", "rising with instances"),
    "W8refit": ("instances", "tlas refit", "rising with instances, below rebuild"),
    "W9": ("triangles", "primary rays", "sub-linear in triangles (log-like traversal depth)"),
    "W10": ("rays_per_pixel", "diffuse rays", "linear in rays per pixel"),
}


def resolve_bundle(path: Path) -> Path:
    """A results root (no run.json) resolves to its newest bundle."""
    if (path / "run.json").exists():
        return path
    candidates = sorted([p for p in path.iterdir() if p.is_dir() and (p / "run.json").exists()],
                        key=lambda p: p.stat().st_mtime)
    if not candidates:
        raise SystemExit(f"no bundle under {path}")
    return candidates[-1]


def numeric(value: str) -> float:
    v = value.strip().lower()
    if "x" in v and v.replace("x", "").isdigit():
        w, h = v.split("x")
        return float(w) * float(h)
    if v.endswith("k"):
        return float(v[:-1]) * 1000.0
    try:
        return float(v)
    except ValueError:
        return 0.0  # unswept workloads (C1 "fixed") have one point and are reported as such


def fit(xs, ys):
    n = len(xs)
    if n < 2:
        return 0.0, 0.0
    mx, my = sum(xs) / n, sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    syy = sum((y - my) ** 2 for y in ys)
    slope = sxy / sxx if sxx > 0 else 0.0
    r = sxy / math.sqrt(sxx * syy) if sxx > 0 and syy > 0 else 0.0
    return slope, r


def main() -> int:
    root = resolve_bundle(Path(sys.argv[1]))
    out_json = sys.argv[sys.argv.index("--json") + 1] if "--json" in sys.argv else None
    run = json.loads((root / "run.json").read_text(encoding="utf-8"))
    report = []
    for wl in run.get("workloads", []):
        wid = wl["id"]
        param, pass_name, expected = EXPECTED.get(wid, (wl.get("sweep_parameter"), None, "unknown"))
        points = []
        floor_ms = {}  # D-37: value -> zero-ray floor of the pass (one per value for resolution sweeps)
        for r in wl.get("runs", []):
            s = json.loads((root / r["dir"].replace("\\", "/") / "summary.json").read_text(encoding="utf-8"))
            passes = s["across_repeats"].get("passes_ms", {})
            if pass_name is None:
                pass_name = next(iter(passes), None)
            if pass_name not in passes:
                continue
            if s["value"].startswith("floor"):  # D-37: the zero-ray floor point is reported, not fitted
                floor_ms[s.get("floor_of", "")] = passes[pass_name]["median_of_repeats"]
                continue
            points.append((numeric(s["value"]), passes[pass_name]["median_of_repeats"], s["value"],
                           passes[pass_name].get("rays_per_frame")))
        points.sort()
        if len(points) < 2:
            report.append({"workload": wid, "pass": pass_name, "expected": expected, "points": len(points)})
            print(f"{wid:8} {pass_name or '-':16} fewer than 2 sweep values; expected {expected}")
            continue
        xs = [p[0] for p in points]
        ys = [p[1] for p in points]
        slope, r = fit(xs, ys)
        ratio_t = ys[-1] / ys[0] if ys[0] > 0 else float("nan")
        ratio_p = xs[-1] / xs[0] if xs[0] > 0 else float("nan")
        entry = {"workload": wid, "pass": pass_name, "parameter": param, "expected": expected,
                 "values": [p[2] for p in points], "pass_ms": ys, "rays_per_frame": [p[3] for p in points],
                 "floor_ms": floor_ms,
                 "slope_ms_per_unit": slope, "correlation": r, "time_ratio_last_first": ratio_t,
                 "parameter_ratio_last_first": ratio_p}
        report.append(entry)
        pts = ", ".join(f"{p[2]}: {p[1]:.3f} ms" for p in points)
        print(f"{wid:8} {pass_name:16} {pts}"
              + ("; floor " + ", ".join(f"{k}: {v:.3f} ms" for k, v in floor_ms.items()) if floor_ms else ""))
        print(f"         expected {expected}; time ratio {ratio_t:.2f} for parameter ratio {ratio_p:.2f}; r = {r:.3f}")
    if out_json:
        Path(out_json).write_text(json.dumps(report, indent=1) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
