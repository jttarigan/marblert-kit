#!/usr/bin/env python3
"""Verifies a runner kit and the test run made from it (docs/PC_TASK.md section 8).

Usage: check_kit_run.py <unzipped kit dir> <reference bundle> [--fingerprint HEX] [--json out.json]

The test bundle is the newest bundle under <kit>/results. Hard checks (any failure: exit 1):
  kit       every file listed in SHA256SUMS.txt is present and unchanged
  bundle    complete, short suite, Vulkan, built from the kit's commit with a clean tree
  shaders   SPIR-V fingerprint equals --fingerprint (default: the reference bundle's)
  pre       preconditions ok
  coverage  the same workload ids as the reference bundle, every run has a summary with a GPU frame time
  V3        every primary-ray depth check passed
  V1        every reference frame shared with the reference bundle passes the image parity gate (D-19)
Reported only: V1 byte-identical count, V2 ray-count ratios and GPU frame-time ratios against the reference
(the short protocol measures fewer frames, so these are expected near 1, not equal). Standard library only.
"""
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import compare_bundles as cb  # noqa: E402  (V1/V2 helpers)


def arg(args, name, default=None):
    return args[args.index(name) + 1] if name in args else default


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def summary(bundle: Path, run: dict) -> dict:
    return json.loads((bundle / run["dir"].replace("\\", "/") / "summary.json").read_text(encoding="utf-8"))


def main() -> int:
    args = sys.argv[1:]
    paths = [a for i, a in enumerate(args) if not a.startswith("--") and (i == 0 or not args[i - 1].startswith("--"))]
    if len(paths) != 2:
        print(__doc__)
        return 2
    kit, ref = Path(paths[0]), cb.resolve_bundle(Path(paths[1]))
    test = cb.resolve_bundle(kit / "results")
    checks = {}
    notes = []

    # kit integrity
    bad = []
    for line in (kit / "SHA256SUMS.txt").read_text(encoding="ascii").splitlines():
        digest, rel = line.split("  ", 1)
        p = kit / rel
        if not p.exists() or sha256(p) != digest:
            bad.append(rel)
    checks["kit"] = not bad
    if bad:
        notes.append(f"kit: {len(bad)} files missing or changed, first: {bad[:5]}")
    commit = (kit / "VERSION").read_text(encoding="ascii").split()[1]

    # bundle identity
    run_t, runs_t = cb.runs_of(test)
    run_r, runs_r = cb.runs_of(ref)
    ident = {"complete": run_t.get("complete") is True, "suite": run_t.get("suite") == "short",
             "backend": run_t.get("backend") == "vulkan", "commit": run_t.get("engine_commit") == commit,
             "clean": run_t.get("engine_dirty") is False}
    checks["bundle"] = all(ident.values())
    if not checks["bundle"]:
        notes.append(f"bundle: {ident} (commit {run_t.get('engine_commit')}, kit {commit})")

    fp_t = run_t.get("shader_build", {}).get("artifacts", {}).get("fnv1a64")
    fp_want = arg(args, "--fingerprint", run_r.get("shader_build", {}).get("artifacts", {}).get("fnv1a64"))
    checks["shaders"] = fp_t == fp_want
    if not checks["shaders"]:
        notes.append(f"shaders: fingerprint {fp_t}, expected {fp_want}")

    checks_t = json.loads((test / "checks.json").read_text(encoding="utf-8"))
    pre = checks_t.get("preconditions", {})
    checks["pre"] = pre.get("ok") is True
    if not checks["pre"]:
        notes.append(f"pre: {pre.get('warnings')}")

    # coverage
    ids_t = {wl["id"] for wl in run_t.get("workloads", [])}
    ids_r = {wl["id"] for wl in run_r.get("workloads", [])}
    empty = []
    for key, (_, r) in runs_t.items():
        try:
            a = summary(test, r)["across_repeats"]
            if not a.get("gpu_frame_ms_median_of_repeats", 0) > 0 or not a.get("passes_ms"):
                empty.append(key)
        except (OSError, KeyError, ValueError):
            empty.append(key)
    checks["coverage"] = ids_t == ids_r and not empty and bool(runs_t)
    if not checks["coverage"]:
        notes.append(f"coverage: missing {sorted(ids_r - ids_t)}, extra {sorted(ids_t - ids_r)}, empty runs {empty}")

    v3 = checks_t.get("v3", [])
    checks["V3"] = bool(v3) and all(x.get("pass") is True for x in v3)
    if not checks["V3"]:
        notes.append(f"V3: {sum(1 for x in v3 if x.get('pass') is not True)} of {len(v3)} failed")

    # V1 against the reference bundle (same device, so byte-identical is expected)
    v1, v2, timing = [], [], []
    for key in sorted(set(runs_t) & set(runs_r)):
        rt, rr = runs_t[key][1], runs_r[key][1]
        refs_t = {x["frame"]: x["file"] for x in rt.get("reference_frames", [])}
        refs_r = {x["frame"]: x["file"] for x in rr.get("reference_frames", [])}
        for frame in sorted(set(refs_t) & set(refs_r)):
            with open(test / rt["dir"].replace("\\", "/") / refs_t[frame], "rb") as f:
                wt, ht, pt = cb.decode_png(f.read())
            with open(ref / rr["dir"].replace("\\", "/") / refs_r[frame], "rb") as f:
                wr, hr, pr = cb.decode_png(f.read())
            m = {"max_abs": 255, "mean_abs": 255.0, "fraction_over_2": 1.0, "identical": False} \
                if (wt, ht) != (wr, hr) else cb.compare(pt, pr, wt * ht)
            m.update(workload=key[0], value=key[1], frame=frame,
                     ok=m["fraction_over_2"] <= 0.005 and m["mean_abs"] <= 0.5)
            v1.append(m)
        st, sr = summary(test, rt), summary(ref, rr)
        for name in sorted(set(st.get("rays", {})) & set(sr.get("rays", {}))):
            xt, xr = st["rays"][name]["rays_per_frame"], sr["rays"][name]["rays_per_frame"]
            v2.append({"workload": key[0], "value": key[1], "pass": name,
                       "ratio": xt / xr if xr else (1.0 if xt == 0 else None)})
        gt = st["across_repeats"]["gpu_frame_ms_median_of_repeats"]
        gr = sr["across_repeats"]["gpu_frame_ms_median_of_repeats"]
        timing.append({"workload": key[0], "value": key[1], "test_ms": gt, "ref_ms": gr, "ratio": gt / gr if gr else None})
    v1_ids = {m["workload"] for m in v1}
    checks["V1"] = bool(v1) and all(m["ok"] for m in v1) and v1_ids == ids_r
    if not checks["V1"]:
        notes.append(f"V1: {sum(1 for m in v1 if not m['ok'])} of {len(v1)} frames fail the gate; "
                     f"workloads without a shared frame: {sorted(ids_r - v1_ids)}")

    ok = all(checks.values())
    print(f"test bundle: {test.name} (commit {run_t.get('engine_commit')}, suite {run_t.get('suite')})")
    print(f"reference:   {ref.name} (commit {run_r.get('engine_commit')}, suite {run_r.get('suite')})")
    for k, v in checks.items():
        print(f"  {k:9} {'pass' if v else 'FAIL'}")
    for n in notes:
        print(f"  - {n}")
    print(f"V1: {len(v1)} frames compared, {sum(1 for m in v1 if m['identical'])} byte-identical, "
          f"worst mean {max((m['mean_abs'] for m in v1), default=0):.4f}")
    r2 = [x["ratio"] for x in v2 if x["ratio"] is not None]
    if r2:
        print(f"V2 (reported): {len(r2)} passes, rays/frame ratio {min(r2):.4f} to {max(r2):.4f}")
    rt_ = [x for x in timing if x["ratio"] is not None]
    if rt_:
        far = [x for x in rt_ if abs(x["ratio"] - 1) > 0.10]
        print(f"GPU frame time (reported): {len(rt_)} runs, ratio short/reference {min(x['ratio'] for x in rt_):.3f} "
              f"to {max(x['ratio'] for x in rt_):.3f}; beyond ±10 %: "
              + (", ".join(f"{x['workload']} {x['value']} {x['ratio']:.3f}" for x in far) or "none"))
    print("RESULT: " + ("PASS" if ok else "FAIL"))
    out_json = arg(args, "--json")
    if out_json:
        Path(out_json).write_text(json.dumps({"result": "pass" if ok else "fail", "checks": checks, "notes": notes,
                                              "test_bundle": test.name, "reference_bundle": ref.name,
                                              "v1": v1, "v2": v2, "timing": timing}, indent=1) + "\n",
                                  encoding="utf-8")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
