#!/usr/bin/env python3
"""Cross-backend and cross-device checks between two bundles (validations V1 and V2).

Usage: compare_bundles.py <bundle A> <bundle B> [--max-diff-fraction F] [--max-mean M] [--json out.json]
For every workload and sweep value present in both bundles: compares the reference frames with
the same frame index (V1: image parity) and the rays per frame of every pass (V2: same work).
Exit status 1 when any pair exceeds the thresholds. Standard library only.
"""
import json
import struct
import sys
import zlib
from pathlib import Path


def decode_png(data: bytes):
    assert data[:8] == b"\x89PNG\r\n\x1a\n", "not a PNG"
    pos = 8
    width = height = 0
    idat = b""
    while pos < len(data):
        length, ctype = struct.unpack(">I4s", data[pos:pos + 8])
        chunk = data[pos + 8:pos + 8 + length]
        pos += 12 + length
        if ctype == b"IHDR":
            width, height, depth, color = struct.unpack(">IIBB", chunk[:10])
            assert depth == 8 and color == 6
        elif ctype == b"IDAT":
            idat += chunk
        elif ctype == b"IEND":
            break
    raw = zlib.decompress(idat)
    bpp = 4
    stride = width * bpp
    out = bytearray(stride * height)
    prev = bytearray(stride)
    off = 0
    for y in range(height):
        filt = raw[off]
        line = bytearray(raw[off + 1:off + 1 + stride])
        off += 1 + stride
        if filt != 0:
            for i in range(stride):
                a = line[i - bpp] if i >= bpp else 0
                b = prev[i]
                c = prev[i - bpp] if i >= bpp else 0
                if filt == 1:
                    line[i] = (line[i] + a) & 0xFF
                elif filt == 2:
                    line[i] = (line[i] + b) & 0xFF
                elif filt == 3:
                    line[i] = (line[i] + ((a + b) >> 1)) & 0xFF
                elif filt == 4:
                    p = a + b - c
                    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                    pred = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                    line[i] = (line[i] + pred) & 0xFF
        out[y * stride:(y + 1) * stride] = line
        prev = line
    return width, height, bytes(out)


def compare(a, b, n):
    total = 0
    max_abs = 0
    over2 = 0
    for i in range(n):
        o = i * 4
        m = max(abs(a[o] - b[o]), abs(a[o + 1] - b[o + 1]), abs(a[o + 2] - b[o + 2]))
        total += abs(a[o] - b[o]) + abs(a[o + 1] - b[o + 1]) + abs(a[o + 2] - b[o + 2])
        if m > max_abs:
            max_abs = m
        if m > 2:
            over2 += 1
    return {"max_abs": max_abs, "mean_abs": total / (3 * n), "fraction_over_2": over2 / n, "identical": a == b}


def resolve_bundle(path: Path) -> Path:
    if (path / "run.json").exists():
        return path
    candidates = sorted([p for p in path.iterdir() if p.is_dir() and (p / "run.json").exists()], key=lambda p: p.stat().st_mtime)
    if not candidates:
        raise SystemExit(f"no bundle under {path}")
    return candidates[-1]


def runs_of(bundle):
    run = json.loads((bundle / "run.json").read_text(encoding="utf-8"))
    out = {}
    for wl in run.get("workloads", []):
        for r in wl.get("runs", []):
            out[(wl["id"], r["value"])] = (wl, r)
    return run, out


def main() -> int:
    args = sys.argv[1:]
    max_fraction = float(args[args.index("--max-diff-fraction") + 1]) if "--max-diff-fraction" in args else 0.005
    max_mean = float(args[args.index("--max-mean") + 1]) if "--max-mean" in args else 0.5
    out_json = args[args.index("--json") + 1] if "--json" in args else None
    paths = [a for i, a in enumerate(args) if not a.startswith("--") and (i == 0 or not args[i - 1].startswith("--"))]
    a = resolve_bundle(Path(paths[0]))
    b = resolve_bundle(Path(paths[1]))
    run_a, runs_a = runs_of(a)
    run_b, runs_b = runs_of(b)
    print(f"A: {a.name} ({run_a.get('backend')}, commit {run_a.get('engine_commit')})")
    print(f"B: {b.name} ({run_b.get('backend')}, commit {run_b.get('engine_commit')})")
    report = []
    failed = False
    for key in sorted(set(runs_a) & set(runs_b)):
        wl, ra = runs_a[key]
        _, rb = runs_b[key]
        entry = {"workload": key[0], "value": key[1], "frames": [], "rays": []}
        refs_a = {x["frame"]: x["file"] for x in ra.get("reference_frames", [])}
        refs_b = {x["frame"]: x["file"] for x in rb.get("reference_frames", [])}
        for frame in sorted(set(refs_a) & set(refs_b)):
            with open(a / ra["dir"].replace("\\", "/") / refs_a[frame], "rb") as f:
                wa, ha, pa = decode_png(f.read())
            with open(b / rb["dir"].replace("\\", "/") / refs_b[frame], "rb") as f:
                wb, hb, pb = decode_png(f.read())
            if (wa, ha) != (wb, hb):
                entry["frames"].append({"frame": frame, "error": f"size {wa}x{ha} vs {wb}x{hb}"})
                failed = True
                continue
            m = compare(pa, pb, wa * ha)
            m["frame"] = frame
            m["pass"] = m["fraction_over_2"] <= max_fraction and m["mean_abs"] <= max_mean
            failed = failed or not m["pass"]
            entry["frames"].append(m)
            print(f"{key[0]:8} {key[1]:>10} frame {frame:5}: V1 identical={m['identical']} max={m['max_abs']:3} "
                  f"mean={m['mean_abs']:.4f} over2={m['fraction_over_2'] * 100:.4f}% {'ok' if m['pass'] else 'FAIL'}")
        sa = json.loads((a / ra["dir"].replace("\\", "/") / "summary.json").read_text(encoding="utf-8")).get("rays", {})
        sb = json.loads((b / rb["dir"].replace("\\", "/") / "summary.json").read_text(encoding="utf-8")).get("rays", {})
        for name in sorted(set(sa) & set(sb)):
            xa, xb = sa[name]["rays_per_frame"], sb[name]["rays_per_frame"]
            ratio = xb / xa if xa else (1.0 if xb == 0 else float("inf"))  # zero-ray floor runs (D-37) match at 0/0
            ok = abs(ratio - 1.0) <= 0.01
            failed = failed or not ok
            entry["rays"].append({"pass": name, "a": xa, "b": xb, "ratio": ratio, "ok": ok})
            print(f"{key[0]:8} {key[1]:>10} {name:16}: V2 rays/frame A={xa:.0f} B={xb:.0f} ratio={ratio:.4f} {'ok' if ok else 'FAIL'}")
        report.append(entry)
    if out_json:
        Path(out_json).write_text(json.dumps(report, indent=1) + "\n", encoding="utf-8")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
