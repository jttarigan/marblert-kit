Python analysis of result bundles (Milestone 5 onwards). Standard library only.

- `check_kit_run.py <unzipped kit> <reference bundle>`: verifies a runner kit (SHA-256 manifest) and its test run
  against a reference bundle from the same machine (identity, shader fingerprint, coverage, V3, V1); `docs/PC_TASK.md` 8.
- `compare_images.py a.png b.png`: per-pixel difference metrics between two frame dumps; used by
  the Milestone 2 portability gate (Vulkan through MoltenVK against Metal).
- `paper_data.py`: numbers and tables for `paper/manuscript.md` from the bundles named in `paper/data_sources.json`;
  writes `paper/generated/` (values.json, tables.md, manuscript.filled.md). Never edits the draft itself.
- `repeat_spread.py <bundle>... [--json]`: the D-35 slow-repeat rule (the same as `engine/bench/repeat_rule.h`): per
  run, flagged repeats, the reported value (median of the clean repeats), V4 and V7 verdicts and the re-measure; for
  bundles older than D-35 the verdict is computed. `summarize.py` and `paper_data.py` import it.
