#!/usr/bin/env python3
"""Compare two RGBA PNG frame dumps and report per-pixel differences.

Usage: compare_images.py a.png b.png [--max-diff-fraction F] [--max-mean M] [--report out.json]

Metrics (per 8-bit channel): max absolute difference, mean absolute difference, and the fraction
of pixels whose largest channel difference exceeds 2 (ignores rounding noise, counts edges).
Exit status 1 if a threshold is given and exceeded. Standard library only; decodes the PNGs that
marblert writes (8-bit RGBA, any row filter).
"""
import json
import struct
import sys
import zlib


def decode_png(data: bytes):
    assert data[:8] == b"\x89PNG\r\n\x1a\n", "not a PNG"
    pos = 8
    width = height = 0
    idat = b""
    while pos < len(data):
        length, ctype = struct.unpack(">I4s", data[pos:pos + 8])
        chunk = data[pos + 8:pos + 8 + length]
        pos += 12 + length
        if ctype == b"IHDR":
            width, height, depth, color = struct.unpack(">IIBB", chunk[:10])
            assert depth == 8 and color == 6, f"expected 8-bit RGBA, got depth {depth} colour type {color}"
        elif ctype == b"IDAT":
            idat += chunk
        elif ctype == b"IEND":
            break
    raw = zlib.decompress(idat)
    bpp = 4
    stride = width * bpp
    out = bytearray(stride * height)
    prev = bytearray(stride)
    off = 0
    for y in range(height):
        filt = raw[off]
        line = bytearray(raw[off + 1:off + 1 + stride])
        off += 1 + stride
        if filt != 0:
            for i in range(stride):
                a = line[i - bpp] if i >= bpp else 0
                b = prev[i]
                c = prev[i - bpp] if i >= bpp else 0
                if filt == 1:
                    line[i] = (line[i] + a) & 0xFF
                elif filt == 2:
                    line[i] = (line[i] + b) & 0xFF
                elif filt == 3:
                    line[i] = (line[i] + ((a + b) >> 1)) & 0xFF
                elif filt == 4:
                    p = a + b - c
                    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                    pred = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                    line[i] = (line[i] + pred) & 0xFF
        out[y * stride:(y + 1) * stride] = line
        prev = line
    return width, height, bytes(out)


def compare(a: bytes, b: bytes, width: int, height: int):
    n = width * height
    total_abs = 0
    max_abs = 0
    over2 = 0
    over16 = 0
    # Work per pixel on the RGB channels (alpha is always 255 in the dumps).
    for i in range(n):
        o = i * 4
        d0 = abs(a[o] - b[o])
        d1 = abs(a[o + 1] - b[o + 1])
        d2 = abs(a[o + 2] - b[o + 2])
        m = d0 if d0 > d1 else d1
        if d2 > m:
            m = d2
        total_abs += d0 + d1 + d2
        if m > max_abs:
            max_abs = m
        if m > 2:
            over2 += 1
        if m > 16:
            over16 += 1
    return {
        "width": width, "height": height, "pixels": n,
        "max_abs": max_abs,
        "mean_abs": total_abs / (3 * n),
        "fraction_over_2": over2 / n,
        "fraction_over_16": over16 / n,
    }


def main() -> int:
    args = sys.argv[1:]
    max_fraction = None
    max_mean = None
    report = None
    paths = []
    i = 0
    while i < len(args):
        if args[i] == "--max-diff-fraction":
            max_fraction = float(args[i + 1]); i += 2
        elif args[i] == "--max-mean":
            max_mean = float(args[i + 1]); i += 2
        elif args[i] == "--report":
            report = args[i + 1]; i += 2
        else:
            paths.append(args[i]); i += 1
    if len(paths) != 2:
        print(__doc__)
        return 2
    with open(paths[0], "rb") as f:
        wa, ha, a = decode_png(f.read())
    with open(paths[1], "rb") as f:
        wb, hb, b = decode_png(f.read())
    if (wa, ha) != (wb, hb):
        print(f"size mismatch: {wa}x{ha} vs {wb}x{hb}")
        return 1
    m = compare(a, b, wa, ha)
    m["a"] = paths[0]
    m["b"] = paths[1]
    m["identical"] = a == b
    print(f"{wa}x{ha}: identical={m['identical']} max_abs={m['max_abs']} mean_abs={m['mean_abs']:.4f} "
          f"over2={m['fraction_over_2'] * 100:.4f}% over16={m['fraction_over_16'] * 100:.4f}%")
    if report:
        with open(report, "w", encoding="utf-8") as f:
            json.dump(m, f, indent=1)
    failed = False
    if max_fraction is not None and m["fraction_over_2"] > max_fraction:
        print(f"FAIL: fraction of pixels differing by more than 2/255 is {m['fraction_over_2']:.6f} > {max_fraction}")
        failed = True
    if max_mean is not None and m["mean_abs"] > max_mean:
        print(f"FAIL: mean absolute difference {m['mean_abs']:.4f} > {max_mean}")
        failed = True
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
