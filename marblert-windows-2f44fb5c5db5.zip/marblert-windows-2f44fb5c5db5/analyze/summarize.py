#!/usr/bin/env python3
"""Print a table from one or more result bundles (summary.json files).

Usage: summarize.py <bundle dir> [...]
Standard library only. Shows, per workload and sweep value: median GPU frame time, the
coefficient of variation between repeats, per-pass medians, Mrays/s for primary rays, the V7
residual (frame minus sum of passes) and the timer overhead against the untimed repeat. Each run
also gets its D-35 line: the reported value (median of the clean repeats), flagged repeats, the V4
and V7 verdicts and its re-measure, if any (rule in repeat_spread.py).
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import repeat_spread as d35  # noqa: E402  (D-35 rule, shared with the harness)


def resolve_bundle(path: Path) -> Path:
    """A results root (no run.json) resolves to its newest bundle."""
    if (path / "run.json").exists():
        return path
    candidates = sorted([p for p in path.iterdir() if p.is_dir() and (p / "run.json").exists()],
                        key=lambda p: p.stat().st_mtime)
    if not candidates:
        raise SystemExit(f"no bundle under {path}")
    return candidates[-1]


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    for root in sys.argv[1:]:
        root = resolve_bundle(Path(root))
        run = json.loads((root / "run.json").read_text(encoding="utf-8"))
        system = json.loads((root / "system.json").read_text(encoding="utf-8"))
        print(f"# {root.name}: {system.get('device_name')} ({system.get('api_version')}), {system.get('os')}, "
              f"commit {run.get('engine_commit')}{' dirty' if run.get('engine_dirty') else ''}, "
              f"backend {run.get('backend')}, timers: {system.get('gpu_timer_method')}")
        for wl in run.get("workloads", []):
            for r in wl.get("runs", []):
                s = json.loads((root / r["dir"].replace("\\", "/") / "summary.json").read_text(encoding="utf-8"))
                a = s["across_repeats"]
                line = (f"{wl['id']:4} {wl['name']:16} {s['value']:>10}  gpu frame {a['gpu_frame_ms_median_of_repeats']:8.3f} ms  "
                        f"cov {a['gpu_frame_ms_cov_between_repeats'] * 100:5.2f}%")
                print(line)
                for name, p in a.get("passes_ms", {}).items():
                    extra = f"  {p['mrays_per_s']:8.1f} Mrays/s" if "mrays_per_s" in p else ""
                    print(f"      {name:16} {p['median_of_repeats']:8.3f} ms  cov {p['cov_between_repeats'] * 100:5.2f}%{extra}")
                timed = [x for x in s["repeats"] if x["timed"]]
                if timed and "residual_ms" in timed[0]:
                    res = [x["residual_ms"]["median"] for x in timed]
                    print(f"      V7 residual (frame - sum of passes) median per repeat: {', '.join(f'{v:.3f}' for v in res)} ms")
                if "timer_overhead" in a:
                    t = a["timer_overhead"]
                    print(f"      V7 timer overhead: timed {t['timed_gpu_frame_ms_median']:.3f} ms vs untimed "
                          f"{t['untimed_gpu_frame_ms_median']:.3f} ms (ratio {t['ratio']:.4f})")
                v = d35.run_verdict(root, r)
                v7 = {True: "pass", False: "fail", None: "not assessed (untimed repeat slow)"}[v.get("v7_pass")]
                print(f"      D-35: reported {v['gpu_frame_ms']:.3f} ms from {v['clean_repeats']} clean of "
                      f"{len(v['timed_ms'])} repeats (flagged {v['flagged_repeats']}), CoV clean "
                      f"{v['gpu_frame_ms_cov_clean'] * 100:.2f}% vs band {v['v4_band'] * 100:.1f}%: V4 "
                      f"{'pass' if v['v4_pass'] else 'fail'}" + (f", V7 {v7}" if "untimed_ms" in v else "")
                      + (f"; re-measured in {v['dir']}" if v["remeasured"] else "")
                      + ("; needs a re-measure (bundle predates D-35)" if v["remeasure_missing"] else ""))
        checks = root / "checks.json"
        if checks.exists():
            c = json.loads(checks.read_text(encoding="utf-8"))
            for v3 in c.get("v3", []):
                print(f"      V3 {v3['workload']} {v3['value']}: agree {v3['agree_fraction_of_both_hit']:.5f}, "
                      f"coverage mismatch {v3['coverage_mismatch_fraction']:.6f}, pass={v3['pass']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
