#!/usr/bin/env python3
"""O-21 check: does the composite workload's repeat-to-repeat spread come from its track content?

C1 replays a 3600-frame track and each suite repeat (120 warm-up + 600 measured frames) continues the frame counter,
so repeat k measures track frames 720k+120 .. 720k+719 and the untimed repeat wraps to repeat 0's stretch. This script
reads the suite's C1 frame table (which stretch each repeat measured and its GPU frame median) and compares every
stretch with the same track frames in one or more sustained runs of C1: there the burst reference period of the
D-31 rule (first 60 s, extended until every track frame has been seen once) gives one burst-level GPU time per track
frame, independent of the suite's repeat boundaries. If the suite's repeat medians equal the sustained run's medians
over the same track frames, the spread is content, not noise. It also reports the whole-track median (what one full
3600-frame pass per repeat, O-21 option A, would measure) and which passes carry the heaviest stretch.

Usage: c1_track.py <suite bundle> <sustained bundle> [<sustained bundle> ...] [--json out.json]
Standard library only.
"""
import csv
import json
import statistics
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from sustained import load_timeline, reference  # noqa: E402

PASSES = ["gbuffer", "tlas build", "shadow rays", "reflection rays", "glass rays", "diffuse rays"]


def suite_repeats(bundle: Path, workload="C1"):
    """[{repeat, timed, frames: [track frames], gpu_median_ms, passes: {name: median}}] from the suite's frame table."""
    rows = list(csv.DictReader(open(bundle / "workloads" / f"{workload}_fixed" / "frames.csv", encoding="utf-8")))
    by_rep = {}
    for r in rows:
        by_rep.setdefault((int(r["repeat"]), r["timed"] == "1"), []).append(r)
    out = []
    for (rep, timed), rs in sorted(by_rep.items()):
        frames = [int(r["track_frame"]) for r in rs]
        gpu = [float(r["gpu_frame_ms"]) for r in rs if r["gpu_frame_ms"]]
        passes = {p: statistics.median(float(r[p]) for r in rs if r.get(p)) for p in PASSES if rs[0].get(p)}
        out.append({"repeat": rep, "timed": timed, "first_frame": min(frames), "last_frame": max(frames),
                    "frames": frames, "gpu_median_ms": statistics.median(gpu), "passes": passes})
    return out


def sustained_reference(bundle: Path):
    """({track frame: burst GPU ms}, {track frame: {pass: burst ms}}) from the sustained run's reference period."""
    rows = load_timeline(bundle)
    ref_end, ref = reference(rows)
    per_pass = {}
    with open(bundle / "sustained" / "timeline.csv", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if float(r["t_s"]) >= ref_end or not r["gpu_frame_ms"]:
                continue
            k = int(r["track_frame"])
            for p in PASSES:
                if r.get(p):
                    per_pass.setdefault(k, {}).setdefault(p, []).append(float(r[p]))
    per_pass = {k: {p: statistics.median(v) for p, v in d.items()} for k, d in per_pass.items()}
    return ref, per_pass


def analyse(suite: Path, sustained: list) -> dict:
    """The comparison as a JSON-ready dict; see the module docstring."""
    reps = suite_repeats(suite)
    refs = {b.name: sustained_reference(b) for b in sustained}
    result = {"suite": suite.name, "sustained": [b.name for b in sustained], "track_frames": None, "repeats": [],
              "whole_track": {}}
    for name, (ref, _) in refs.items():
        result["track_frames"] = len(ref)
        result["whole_track"][name] = statistics.median(ref.values())
    worst = 0.0
    for r in reps:
        row = {k: r[k] for k in ("repeat", "timed", "first_frame", "last_frame", "gpu_median_ms")}
        row["sustained_median_ms"], row["ratio"] = {}, {}
        for name, (ref, _) in refs.items():
            m = statistics.median(ref[k] for k in r["frames"] if k in ref)
            row["sustained_median_ms"][name] = m
            row["ratio"][name] = r["gpu_median_ms"] / m
            worst = max(worst, abs(row["ratio"][name] - 1.0))
        result["repeats"].append(row)
    result["max_abs_deviation"] = worst
    timed = [r for r in reps if r["timed"]]
    # O-21 option A (2026-10-22): every repeat covers the whole track, so the stretches coincide.
    result["full_track"] = all(len(set(r["frames"])) >= result["track_frames"] for r in reps) if result["track_frames"] else False
    heavy, light = max(timed, key=lambda r: r["gpu_median_ms"]), min(timed, key=lambda r: r["gpu_median_ms"])
    result["heaviest_repeat"], result["lightest_repeat"] = heavy["repeat"], light["repeat"]
    result["heavy_to_light"] = heavy["gpu_median_ms"] / light["gpu_median_ms"]
    result["pass_difference_ms"] = {p: heavy["passes"][p] - light["passes"][p] for p in heavy["passes"]}
    result["pass_medians_ms"] = {"heaviest": heavy["passes"], "lightest": light["passes"]}
    cov = statistics.stdev(r["gpu_median_ms"] for r in timed) / statistics.mean(r["gpu_median_ms"] for r in timed)
    result["suite_repeat_cov"] = cov
    # the same stretch pattern in each sustained run: its heaviest-stretch / lightest-stretch ratio
    result["heavy_to_light_sustained"] = {
        n: max(r["sustained_median_ms"][n] for r in result["repeats"] if r["timed"])
        / min(r["sustained_median_ms"][n] for r in result["repeats"] if r["timed"]) for n in refs}
    return result


def main() -> int:
    args = sys.argv[1:]
    out_json = None
    if "--json" in args:
        i = args.index("--json")
        out_json = Path(args[i + 1])
        del args[i:i + 2]
    if len(args) < 2:
        print(__doc__)
        return 2
    suite, sustained = Path(args[0]), [Path(a) for a in args[1:]]
    result = analyse(suite, sustained)
    refs = result["sustained"]
    timed = [r for r in result["repeats"] if r["timed"]]
    heavy = next(r for r in timed if r["repeat"] == result["heaviest_repeat"])
    light = next(r for r in timed if r["repeat"] == result["lightest_repeat"])
    cov, worst = result["suite_repeat_cov"], result["max_abs_deviation"]

    print(f"C1 in {suite.name}: {len(timed)} timed repeats, CoV {cov * 100:.1f} %, "
          f"heaviest / lightest {result['heavy_to_light']:.3f} (repeats {heavy['repeat']} / {light['repeat']})")
    print("repeat  timed  track frames   suite ms   " + "   ".join(f"{n[-16:]:>16}" for n in refs))
    for row in result["repeats"]:
        cells = "   ".join(f"{row['sustained_median_ms'][n]:8.3f} ({row['ratio'][n]:.3f})" for n in refs)
        print(f"{row['repeat']:>6}  {'yes' if row['timed'] else 'no ':>5}  {row['first_frame']:>5}-{row['last_frame']:<5}"
              f"  {row['gpu_median_ms']:8.3f}   {cells}")
    print("whole track (3600 frames, burst): " + ", ".join(f"{n}: {m:.3f} ms" for n, m in result["whole_track"].items()))
    print("heaviest / lightest stretch in the sustained runs: "
          + ", ".join(f"{n}: {x:.3f}" for n, x in result["heavy_to_light_sustained"].items()))
    print(f"largest deviation suite vs sustained over the same frames: {worst * 100:.2f} %")
    diff = sorted(result["pass_difference_ms"].items(), key=lambda kv: -kv[1])
    print("heaviest minus lightest stretch per pass (ms): " + ", ".join(f"{p} {d:+.3f}" for p, d in diff))
    if out_json:
        out_json.write_text(json.dumps(result, indent=1), encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
