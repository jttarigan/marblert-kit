#!/usr/bin/env python3
"""O-20 A/B analysis: slow repeats per display condition, from a tools/mac_session/o20_ab.sh session.

Usage: o20_ab.py results/sessions/o20_<stamp> [--json]

For every workload, each timed repeat's GPU frame median is divided by the fastest repeat of that workload over
all blocks. A repeat is slow when that ratio exceeds 1.05 (the O-04 flag) or 1.20 (the 2026-10-20 dips were 1.2-2.9x).
Slow-repeat counts per condition are compared with a two-sided Fisher exact test. Standard library only.
"""
import csv
import json
import math
import sys
from pathlib import Path

THRESHOLDS = (1.05, 1.20)


def fisher_two_sided(a: int, b: int, c: int, d: int) -> float:
    """2x2 table [[a, b], [c, d]]; sum of hypergeometric probabilities not above the observed one."""
    n1, n2, k, n = a + b, c + d, a + c, a + b + c + d

    def p(x: int) -> float:
        return math.comb(n1, x) * math.comb(n2, k - x) / math.comb(n, k)

    observed = p(a)
    return min(1.0, sum(p(x) for x in range(max(0, k - n2), min(k, n1) + 1) if p(x) <= observed * (1 + 1e-9)))


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        return 2
    session = Path(args[0])
    blocks = list(csv.DictReader(open(session / "blocks.tsv"), delimiter="\t"))
    rows = []  # (block, condition, workload label, repeat, gpu median, p95)
    for b in blocks:
        if b["bundle"] == "none":
            continue
        bundle = Path(b["bundle"])
        for wl in json.loads((bundle / "run.json").read_text()).get("workloads", []):
            for r in wl.get("runs", []):
                s = json.loads((bundle / r["dir"].replace("\\", "/") / "summary.json").read_text())
                name = f"{s['workload']}/{s['value']}"
                for rep in s["repeats"]:
                    if rep["timed"]:  # the untimed repeat measures timer overhead (V7), not repeatability
                        g = rep["gpu_frame_ms"]
                        rows.append((int(b["block"]), b["condition"], name, rep["repeat"], g["median"], g["p95"]))
    if not rows:
        print("no bundles")
        return 1
    fastest = {}
    for _, _, name, _, med, _ in rows:
        fastest[name] = min(fastest.get(name, math.inf), med)

    out = {"session": str(session), "blocks": blocks, "workloads": {}, "conditions": {}}
    print(f"{session.name}: {len(blocks)} blocks, {len(rows)} timed repeats")
    for name in sorted(fastest):
        print(f"\n{name} (fastest repeat median {fastest[name]:.4f} ms)")
        out["workloads"][name] = {"fastest_ms": fastest[name], "blocks": {}}
        for b in blocks:
            reps = [r for r in rows if r[0] == int(b["block"]) and r[2] == name]
            ratios = [r[4] / fastest[name] for r in reps]
            out["workloads"][name]["blocks"][b["block"]] = {"condition": b["condition"], "ratios": ratios}
            print(f"  block {b['block']} {b['condition']:<11} " + " ".join(f"{x:5.2f}" for x in ratios))
    conds = sorted({r[1] for r in rows})
    print()
    for t in THRESHOLDS:
        counts = {}
        for c in conds:
            rs = [r for r in rows if r[1] == c]
            slow = sum(1 for r in rs if r[4] / fastest[r[2]] > t)
            counts[c] = (slow, len(rs))
            out["conditions"].setdefault(c, {})[f"slow_over_{t:.2f}"] = {"slow": slow, "repeats": len(rs)}
        line = ", ".join(f"{c} {s}/{n}" for c, (s, n) in counts.items())
        if {"on", "asleep"} <= counts.keys():
            (s1, n1), (s2, n2) = counts["on"], counts["asleep"]
            pv = fisher_two_sided(s1, n1 - s1, s2, n2 - s2)
            out["conditions"][f"fisher_p_{t:.2f}"] = pv
            line += f"; Fisher two-sided p = {pv:.4f}"
        print(f"slow repeats (> {t:.2f}x fastest): {line}")
    if "--json" in args:
        (session / "o20_analysis.json").write_text(json.dumps(out, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
