#!/usr/bin/env python3
"""Re-analyses a sustained run from its bundle files with the D-31 steady-state rule, for frame time and
(when power.csv exists) for power. Mirrors engine/bench/harness.cpp so old bundles can be re-read and
hand-merged power logs (tools/analyze/power.py) get the same treatment.

Rule: every frame is divided by the burst-period median of the same track frame (reference period: the
first 60 s, extended until every track frame has been seen once). Over 60 s windows of these ratios,
steady state starts at the first window from which all remaining windows (at least 5) stay within a
2 % band; otherwise "not reached". Power uses the same windows and band on the window mean power.

Usage: sustained.py <bundle dir> [--json out.json]
Standard library only.
"""
import csv
import json
import statistics
import sys
from pathlib import Path

WINDOW_S = 60.0
BAND = 0.02
TAIL = 5


def steady_start(series):
    """series: [(window start, value)]; first start whose remaining tail (>= TAIL) stays within BAND."""
    for i in range(len(series) - TAIL + 1):
        tail = [v for _, v in series[i:]]
        if max(tail) <= min(tail) * (1.0 + BAND):
            return series[i][0]
    return None


def load_timeline(root):
    """[(t_s, track_frame, gpu_frame_ms)] from the bundle's sustained timeline."""
    rows = list(csv.DictReader(open(root / "sustained" / "timeline.csv", encoding="utf-8")))
    return [(float(r["t_s"]), int(r["track_frame"]), float(r["gpu_frame_ms"])) for r in rows if r["gpu_frame_ms"]]


def reference(rows):
    """(reference period end, {track frame: burst-period median}); the period is the first WINDOW_S seconds,
    extended until every track frame has been seen once."""
    frames = {k for _, k, _ in rows}
    seen, all_seen = set(), None
    for t, k, _ in rows:
        seen.add(k)
        if len(seen) == len(frames):
            all_seen = t
            break
    ref_end = max(WINDOW_S, all_seen + 1e-9)
    ref = {}
    for t, k, g in rows:
        if t < ref_end:
            ref.setdefault(k, []).append(g)
    return ref_end, {k: statistics.median(v) for k, v in ref.items()}


def load_power(root):
    """[(t_s, combined_mw, gpu_mw)] from power.csv, or None when the bundle has no power log."""
    path = root / "power.csv"
    if not path.exists():
        return None
    prow = [r for r in csv.DictReader(l for l in open(path, encoding="utf-8") if not l.startswith("#"))]
    return [(float(r["t_s"]), float(r["combined_mw"]), float(r["gpu_mw"])) for r in prow]


def main() -> int:
    root = Path(sys.argv[1])
    rows = load_timeline(root)
    total = rows[-1][0]
    ref_end, ref = reference(rows)
    burst = statistics.median(g for t, _, g in rows if t < 30.0)

    windows, ratios = [], []
    w = 0.0
    while w + WINDOW_S <= total + 1e-6:
        sel = [(k, g) for t, k, g in rows if w <= t < w + WINDOW_S]
        rs = [g / ref[k] for k, g in sel if k in ref]
        win = {"start_s": w, "median_gpu_frame_ms": statistics.median(g for _, g in sel),
               "ratio_to_burst": statistics.median(rs) if rs else None}
        windows.append(win)
        if rs:
            ratios.append((w, win["ratio_to_burst"]))
        w += WINDOW_S
    t_steady = steady_start(ratios)
    steady = statistics.median(g for t, _, g in rows if t >= t_steady) if t_steady is not None else None

    out = {"rule": "D-31", "reference_period_s": ref_end, "duration_s": total,
           "burst_gpu_frame_ms_median": burst, "steady_detected": t_steady is not None,
           "time_to_steady_s": t_steady, "steady_gpu_frame_ms_median": steady,
           "steady_to_burst_ratio": steady / burst if steady else None, "windows": windows}

    prow = load_power(root)
    if prow is not None:
        idle = [c for t, c, _ in prow if -120.0 <= t < -5.0]
        pw = []
        for win in windows:
            s = [c for t, c, _ in prow if win["start_s"] <= t < win["start_s"] + WINDOW_S]
            win["mean_combined_mw"] = statistics.fmean(s) if s else None
            if s:
                pw.append((win["start_s"], win["mean_combined_mw"]))
        tp = steady_start(pw)
        out["power"] = {"idle_combined_mw_median": statistics.median(idle) if idle else None,
                        "burst_mean_combined_mw": statistics.fmean(c for t, c, _ in prow if 0.0 <= t < 30.0),
                        "steady_detected": tp is not None, "time_to_steady_s": tp,
                        "steady_mean_combined_mw": statistics.fmean(c for t, c, _ in prow if tp is not None and t >= tp and t <= total) if tp is not None else None}

    print(f"{root.name}: {total:.0f} s, reference period {ref_end:.0f} s")
    print(f"  burst {burst:.3f} ms; steady " + (f"from {t_steady:.0f} s: {steady:.3f} ms (x{steady / burst:.3f})" if t_steady is not None else "not reached"))
    for win in windows:
        extra = f"  {win['mean_combined_mw'] / 1000:6.2f} W" if win.get("mean_combined_mw") else ""
        r = win["ratio_to_burst"]
        print(f"  {win['start_s']:5.0f} s  {win['median_gpu_frame_ms']:7.3f} ms  ratio {r:6.3f}{extra}" if r else f"  {win['start_s']:5.0f} s")
    if "power" in out:
        p = out["power"]
        idle = f"{p['idle_combined_mw_median'] / 1000:.2f} W" if p["idle_combined_mw_median"] is not None else "n/a"
        print(f"  power: idle {idle}, burst {p['burst_mean_combined_mw'] / 1000:.2f} W, steady "
              + (f"from {p['time_to_steady_s']:.0f} s: {p['steady_mean_combined_mw'] / 1000:.2f} W" if p["steady_detected"] else "not reached"))
    if "--json" in sys.argv:
        Path(sys.argv[sys.argv.index("--json") + 1]).write_text(json.dumps(out, indent=1), encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
