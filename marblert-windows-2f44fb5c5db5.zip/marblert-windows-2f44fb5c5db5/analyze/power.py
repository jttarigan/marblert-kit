#!/usr/bin/env python3
"""Converts a powermetrics text log captured by hand (`sudo powermetrics --samplers cpu_power,gpu_power
-i 1000 > power.txt`) into the bundle's power.csv layout, aligned to a sustained run's start.

Usage: power.py power.txt --bundle <bundle dir> [--out power.csv]
Alignment uses the bundle's run.json "started_utc" plus the sustained warm-up; it is approximate
(one second) and is recorded as such in the output header.
"""
import datetime
import json
import re
import sys
from pathlib import Path

STAMP = re.compile(r"\*\*\* Sampled system activity \((.+?)\) \(")


def main() -> int:
    args = sys.argv[1:]
    src = Path(args[0])
    bundle = Path(args[args.index("--bundle") + 1])
    out = Path(args[args.index("--out") + 1]) if "--out" in args else bundle / "power.csv"
    run = json.loads((bundle / "run.json").read_text(encoding="utf-8"))
    start = datetime.datetime.strptime(run["started_utc"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=datetime.timezone.utc)
    rows = []
    t = None
    cpu = gpu = comb = None
    for line in src.read_text(encoding="utf-8", errors="replace").splitlines():
        m = STAMP.search(line)
        if m:
            try:
                t = datetime.datetime.strptime(m.group(1), "%a %b %d %H:%M:%S %Y %z")
            except ValueError:
                t = None
            cpu = gpu = comb = None
            continue
        if line.startswith("CPU Power:"):
            cpu = float(line.split(":")[1].split()[0])
        elif line.startswith("GPU Power:"):
            gpu = float(line.split(":")[1].split()[0])
        elif line.startswith("Combined Power"):
            comb = float(line.split(":")[1].split()[0])
            if t is not None:
                rows.append(((t - start).total_seconds(), cpu, gpu, comb))
    with open(out, "w", encoding="utf-8") as f:
        f.write("# aligned to run.json started_utc (about 1 s accuracy); t_s is seconds since the run started\n")
        f.write("t_s,cpu_mw,gpu_mw,combined_mw\n")
        for r in rows:
            f.write(",".join("" if v is None else f"{v}" for v in r) + "\n")
    print(f"wrote {len(rows)} samples to {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
