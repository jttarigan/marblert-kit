#!/usr/bin/env python3
"""Writes one SVG line chart per workload sweep from a bundle: median pass time (with the
between-repeat spread) against the swept parameter. Standard library only, so it runs anywhere.

Usage: plots.py <bundle dir> [--out DIR]
"""
import json
import sys
from pathlib import Path

W, H, L, R, T, B = 640, 400, 70, 20, 30, 60


def resolve_bundle(path: Path) -> Path:
    """A results root (no run.json) resolves to its newest bundle."""
    if (path / "run.json").exists():
        return path
    candidates = sorted([p for p in path.iterdir() if p.is_dir() and (p / "run.json").exists()],
                        key=lambda p: p.stat().st_mtime)
    if not candidates:
        raise SystemExit(f"no bundle under {path}")
    return candidates[-1]


def numeric(value: str) -> float:
    v = value.strip().lower()
    if "x" in v and v.replace("x", "").isdigit():
        w, h = v.split("x")
        return float(w) * float(h) / 1.0e6
    if v.endswith("k"):
        return float(v[:-1]) * 1000.0
    return float(v)


def svg_chart(title, xlabel, series, out_path):
    # series: list of (name, [(x, y, lo, hi)])
    xs = [p[0] for _, pts in series for p in pts]
    ys = [p[3] for _, pts in series for p in pts] + [p[1] for _, pts in series for p in pts]
    x0, x1 = min(xs), max(xs)
    y0, y1 = 0.0, max(ys) * 1.1 if ys else 1.0
    if x1 == x0:
        x1 = x0 + 1.0

    def sx(x):
        return L + (x - x0) / (x1 - x0) * (W - L - R)

    def sy(y):
        return T + (1.0 - (y - y0) / (y1 - y0)) * (H - T - B)

    colours = ["#2563eb", "#dc2626", "#16a34a", "#9333ea"]
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" font-family="sans-serif" font-size="12">',
             f'<rect width="{W}" height="{H}" fill="white"/>',
             f'<text x="{W / 2}" y="18" text-anchor="middle" font-size="14">{title}</text>',
             f'<line x1="{L}" y1="{sy(y0)}" x2="{W - R}" y2="{sy(y0)}" stroke="#444"/>',
             f'<line x1="{L}" y1="{T}" x2="{L}" y2="{H - B}" stroke="#444"/>',
             f'<text x="{(L + W - R) / 2}" y="{H - 20}" text-anchor="middle">{xlabel}</text>',
             f'<text x="16" y="{(T + H - B) / 2}" text-anchor="middle" transform="rotate(-90 16 {(T + H - B) / 2})">median pass time (ms)</text>']
    for k in range(5):
        y = y0 + (y1 - y0) * k / 4
        parts.append(f'<line x1="{L}" y1="{sy(y)}" x2="{W - R}" y2="{sy(y)}" stroke="#ddd"/>')
        parts.append(f'<text x="{L - 6}" y="{sy(y) + 4}" text-anchor="end">{y:.2f}</text>')
    for i, (name, pts) in enumerate(series):
        c = colours[i % len(colours)]
        for x, y, lo, hi in pts:
            parts.append(f'<line x1="{sx(x)}" y1="{sy(lo)}" x2="{sx(x)}" y2="{sy(hi)}" stroke="{c}" stroke-width="1"/>')
        path = " ".join(f"{'M' if j == 0 else 'L'}{sx(x)},{sy(y)}" for j, (x, y, _, _) in enumerate(pts))
        parts.append(f'<path d="{path}" fill="none" stroke="{c}" stroke-width="2"/>')
        for x, y, _, _ in pts:
            parts.append(f'<circle cx="{sx(x)}" cy="{sy(y)}" r="3.5" fill="{c}"/>')
            parts.append(f'<text x="{sx(x)}" y="{H - B + 16}" text-anchor="middle">{x:g}</text>')
        parts.append(f'<text x="{W - R - 4}" y="{T + 14 + 16 * i}" text-anchor="end" fill="{c}">{name}</text>')
    parts.append("</svg>")
    Path(out_path).write_text("\n".join(parts) + "\n", encoding="utf-8")


def main() -> int:
    root = resolve_bundle(Path(sys.argv[1]))
    out_dir = Path(sys.argv[sys.argv.index("--out") + 1]) if "--out" in sys.argv else root / "plots"
    out_dir.mkdir(parents=True, exist_ok=True)
    run = json.loads((root / "run.json").read_text(encoding="utf-8"))
    n = 0
    for wl in run.get("workloads", []):
        per_pass = {}
        for r in wl.get("runs", []):
            s = json.loads((root / r["dir"].replace("\\", "/") / "summary.json").read_text(encoding="utf-8"))
            x = numeric(s["value"])
            for name, p in s["across_repeats"].get("passes_ms", {}).items():
                meds = [rep["passes_ms"][name]["median"] for rep in s["repeats"] if rep["timed"] and name in rep.get("passes_ms", {})]
                lo, hi = (min(meds), max(meds)) if meds else (p["median_of_repeats"], p["median_of_repeats"])
                per_pass.setdefault(name, []).append((x, p["median_of_repeats"], lo, hi))
        series = [(name, sorted(pts)) for name, pts in per_pass.items()]
        if not series:
            continue
        xlabel = wl.get("sweep_parameter", "value")
        if xlabel == "resolution":
            xlabel = "megapixels"
        svg_chart(f"{wl['id']} {wl['name']}", xlabel, series, out_dir / f"{wl['id']}.svg")
        n += 1
    print(f"wrote {n} charts to {out_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
