# MarbleRT runner guide (Windows)

Thank you for running this. It takes about 10 minutes (short suite) or about 100 minutes (full suite of about
65 minutes on an RTX 3060 Ti, then the 30-minute sustained run). Nothing is installed; the folder is self-contained
and can be deleted afterwards.

## What you need

- Windows 10 or 11, 64-bit.
- A GPU with hardware ray tracing and Vulkan ray queries (`VK_KHR_ray_query`): NVIDIA GeForce RTX 20 series or newer,
  AMD Radeon RX 6000 series or newer, or Intel Arc. A current driver from the GPU maker; nothing else.

## Before you start

1. A laptop must be on mains power, with the power mode at "Best performance". On a desktop, choose the
   "High performance" or "Ultimate Performance" power plan if one exists.
2. Quit other applications, especially browsers, games, video calls, game launchers and overlays, and anything else
   that uses the GPU.
3. Leave the PC alone while it runs, and make sure it will not go to sleep in the meantime (Settings, System,
   Power: screen and sleep).

## Run

Unzip the kit to a folder whose path has no special characters (for example `C:\marblert`), open the folder and
double-click:

- short suite: `run_short.bat`
- full suite: `run_full.bat`

A console window prints progress. If Windows SmartScreen says it "protected your PC", choose "More info", then
"Run anyway": the program is not signed. A warning about power in the console means the run continues but will be
marked.

## What to send back

Zip the `results` folder inside the kit folder and send it. It contains only measurements and a description of the
hardware and operating system (GPU and CPU names, driver and Windows version, memory size, computer name). No files,
personal data, or anything outside this folder are read.

## If something goes wrong

- "device creation failed", "device has no ray query support" or a crash at start: send the text in the console
  window. The GPU or driver may lack ray queries; updating the driver can help.
- The PC went to sleep: run it again; the earlier results folder can be deleted.
- `SHA256SUMS.txt` lists a checksum for every file in the kit, if you want to check the download.
